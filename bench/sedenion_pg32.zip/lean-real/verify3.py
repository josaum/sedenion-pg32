import sympy as sp, torch, json, sys
sys.path.insert(0, '/home/claude/bench/pkg')
from sedenion_pg32 import tables
S, _, _ = tables(); S = S.to(torch.int64).tolist()
def omul(x, y):
    out = [0] * 8
    for i in range(8):
        for j in range(8): out[i ^ j] += S[i][j] * x[i] * y[j]
    return [sp.expand(e) for e in out]
a = [0] + list(sp.symbols('a1:8')); b = [0] + list(sp.symbols('b1:8')); c = list(sp.symbols('c0:8'))
dot = lambda x, y: sum(x[i] * y[i] for i in range(8)); e0 = [1] + [0] * 7; ab = omul(a, b)
lin = lambda *terms: [sp.expand(sum(k * v[i] for k, v in terms)) for i in range(8)]
Pi = lin((1, c), (-c[0], e0), (-dot(a, c), a), (-dot(b, c), b), (-dot(ab, c), ab))
g = [dot(a, b), dot(a, a) - 1, dot(b, b) - 1]
cands = {
    "e0": (Pi[0], [dot(ab, c), 0, 0]),
    "a": (dot(a, Pi), [-dot(b, c), -dot(a, c), 0]),
    "b": (dot(b, Pi), [-dot(a, c), 0, -dot(b, c)]),
    "ab": (dot(ab, Pi), [c[0], -dot(ab, c) * dot(b, b), -dot(ab, c)]),
}
out = {}
for k, (f, lam) in cands.items():
    ok = sp.expand(f - sum(l * gg for l, gg in zip(lam, g))) == 0
    print(k, ok, flush=True); assert ok
    out[k] = [str(sp.expand(l)) for l in lam]
json.dump(out, open('/home/claude/bench/lean-real/certs3.json', 'w'), indent=1)
