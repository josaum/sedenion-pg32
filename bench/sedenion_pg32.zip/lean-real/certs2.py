import sympy as sp, torch, json, sys
sys.path.insert(0,'/home/claude/bench/pkg')
from sedenion_pg32 import tables
S,_,_=tables(); S=S.to(torch.int64).tolist()
def omul(x,y):
    out=[0]*8
    for i in range(8):
        for j in range(8): out[i^j]+= S[i][j]*x[i]*y[j]
    return [sp.expand(e) for e in out]
a=[0]+list(sp.symbols('a1:8')); b=[0]+list(sp.symbols('b1:8'))
c=list(sp.symbols('c0:8')); d=list(sp.symbols('d0:8'))
conj=lambda x:[x[0]]+[-t for t in x[1:]]
dot=lambda x,y: sum(x[i]*y[i] for i in range(8))
e0=[1]+[0]*7
ab=omul(a,b)
def smul(u,v):  # (a,b)(c,d) = (ac - d* b, da + b c*)
    (p,q),(r,s)=u,v
    f=[sp.expand(x-y) for x,y in zip(omul(p,r),omul(conj(s),q))]
    g=[sp.expand(x+y) for x,y in zip(omul(s,p),omul(q,conj(r)))]
    return (f,g)
lin=lambda *terms: [sp.expand(sum(k*v[i] for k,v in terms)) for i in range(8)]
T2=lambda c: lin((1,omul(omul(a,c),b)),(-c[0],ab),(dot(a,c),b),(dot(b,c),a),(-dot(ab,c),e0))
T1=lambda d: lin((1,omul(a,omul(d,b))),(-dot(ab,d),e0),(dot(b,d),a),(dot(a,d),b),(-d[0],ab))
Pi=lambda c: lin((1,c),(-c[0],e0),(-dot(a,c),a),(-dot(b,c),b),(-dot(ab,c),ab))
g=[dot(a,b), dot(a,a)-1, dot(b,b)-1]
abv=a[1:]+b[1:]
def solve(f, xs, deg_ab):
    """certificate f = Σ λ_i g_i with λ_i of degree ≤ deg_ab in (a,b) and linear in xs"""
    mon_ab=[sp.Integer(1)]
    if deg_ab>=1: mon_ab+=list(abv)
    if deg_ab>=2: mon_ab+=[abv[i]*abv[j] for i in range(14) for j in range(i,14)]
    mons=[m*x for m in mon_ab for x in xs]
    coef=sp.symbols(f'l0:{3*len(mons)}')
    expr=f-sum(coef[i*len(mons)+m]*mons[m]*g[i] for i in range(3) for m in range(len(mons)))
    allv=abv+list(xs)
    eqs=sp.Poly(sp.expand(expr),*allv).coeffs()
    sol=sp.linsolve(eqs,coef)
    assert sol, "no certificate"
    sol=list(sol)[0]; sol=[s.subs({cc:0 for cc in coef}) for s in sol]
    return [str(sp.expand(sum(sol[i*len(mons)+m]*mons[m] for m in range(len(mons))))) for i in range(3)]
certs={}
uu=smul((a,b),(a,b)) if False else None
inner=smul((a,b),(c,d)); outer=smul((a,b),inner)
rhs=(lin((-2,c),(2,T1(d))), lin((-2,d),(2,T2(c))))
for blk,(L,R) in enumerate(zip(outer,rhs)):
    for k in range(8):
        f=sp.expand(L[k]-R[k])
        certs[f"I1_{blk}_{k}"]=["0"]*3 if f==0 else solve(f,c+d,0)
        print("I1",blk,k,certs[f"I1_{blk}_{k}"],flush=True)
        json.dump(certs,open('certs2.json','w'),indent=1)
t=T1(T2(c)); p=Pi(c)
for k in range(8):
    f=sp.expand(t[k]-p[k])
    certs[f"I2_{k}"]=["0"]*3 if f==0 else solve(f,c,2)
    print("I2",k,[s[:60] for s in certs[f"I2_{k}"]],flush=True)
    json.dump(certs,open('certs2.json','w'),indent=1)
print("DONE")
