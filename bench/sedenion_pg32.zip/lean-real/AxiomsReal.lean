import SedenionDim
#print axioms SedenionReal.nullspace
#print axioms SedenionReal.composition
#print axioms SedenionReal.partner_norm
#print axioms SedenionReal.partner_linear
#print axioms SedenionReal.basis_mul_sign
#print axioms SedenionReal.square_identity
#print axioms SedenionReal.adjoint_identity
#print axioms SedenionReal.kernel_char
#print axioms SedenionReal.ker_Lu_eq
#print axioms SedenionReal.finrank_ker_Lu
#print axioms SedenionReal.finrank_range_Lu
