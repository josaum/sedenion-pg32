"""Generate SedenionReal.lean: Theorem 5.1 over ℝ from the sympy certificates."""
import json, sys, re, torch
sys.path.insert(0, '/home/claude/bench/pkg')
from sedenion_pg32 import tables
S, _, _ = tables(); S = S.to(torch.int64).tolist()

certs = json.load(open('/home/claude/bench/lean-real/certs.json'))

def lean_poly(s):
    s = s.replace('**', '^')
    return s if s != '0' else '0'

# octonion product formulas: out_k = Σ_{i^j=k} S[i][j] x_i y_j
def omul_comp(k):
    terms = []
    for i in range(8):
        j = i ^ k
        sgn = S[i][j]
        terms.append(f"{'-' if sgn < 0 else '+'} x.c{i} * y.c{j}")
    t = ' '.join(terms)
    return t[2:] if t.startswith('+ ') else '-' + t[2:]

fields = ' '.join(f'c{i}' for i in range(8))
lines = [f"""/-
  SedenionReal.lean — Theorem 5.1 (Constructive 4D Moreno Nullspace) over ℝ.

  Octonions are 8 real coordinates with the product given by the same Cayley–Dickson
  structure constants as `SedenionPG32.Core.eps` (top-left 8×8 block); sedenions are pairs
  (a, b) ∈ O × O with the doubling product  (a,b)(c,d) = (ac − d* b, da + b c*).

  The theorem is an ideal-membership statement: every coordinate of u·v is a polynomial
  combination of the six constraint polynomials.  The multipliers were found by linear
  algebra (certs.py) and are verified here by `linear_combination`, i.e. by `ring`.
  No `sorry`, no `native_decide`.
-/
import Mathlib.Tactic

namespace SedenionReal

@[ext] structure O where
  ({fields} : ℝ)

/-- conjugation: negate the imaginary part -/
def conj (x : O) : O := ⟨x.c0, -x.c1, -x.c2, -x.c3, -x.c4, -x.c5, -x.c6, -x.c7⟩

/-- octonion product, e_i e_j = ε_ij e_(i xor j) with the Cayley–Dickson signs -/
def omul (x y : O) : O := ⟨
"""]
lines.append(',\n'.join('  ' + omul_comp(k) for k in range(8)) + '⟩\n')
lines.append("""
/-- Euclidean inner product on O -/
def dot (x y : O) : ℝ :=
  x.c0 * y.c0 + x.c1 * y.c1 + x.c2 * y.c2 + x.c3 * y.c3 + x.c4 * y.c4 + x.c5 * y.c5 + x.c6 * y.c6 + x.c7 * y.c7

def osub (x y : O) : O := ⟨x.c0 - y.c0, x.c1 - y.c1, x.c2 - y.c2, x.c3 - y.c3, x.c4 - y.c4, x.c5 - y.c5, x.c6 - y.c6, x.c7 - y.c7⟩
def oadd (x y : O) : O := ⟨x.c0 + y.c0, x.c1 + y.c1, x.c2 + y.c2, x.c3 + y.c3, x.c4 + y.c4, x.c5 + y.c5, x.c6 + y.c6, x.c7 + y.c7⟩
def ozero : O := ⟨0, 0, 0, 0, 0, 0, 0, 0⟩

/-- sedenion = pair of octonions; Cayley–Dickson doubling product (eq. cd_doubling) -/
def smul (u v : O × O) : O × O :=
  (osub (omul u.1 v.1) (omul (conj v.2) u.2), oadd (omul v.2 u.1) (omul u.2 (conj v.1)))

/-- the constructive partner d = (a c) b of Theorem 5.1 -/
def partner (a b c : O) : O := omul (omul a c) b

/-- **Theorem 5.1 (Constructive 4D Zero-Divisor Nullspace Operator).**
    Let a, b, c be purely imaginary octonions with ‖a‖ = ‖b‖ = 1, ⟨a,b⟩ = 0 and
    c ⊥ span{a, b, ab}.  Then the sedenion u = (a, b) annihilates v = (c, (ac)b):  u·v = 0. -/
theorem nullspace
    (a b c : O)
    (ha0 : a.c0 = 0) (hb0 : b.c0 = 0) (hc0 : c.c0 = 0)
    (hab : dot a b = 0) (hac : dot a c = 0) (hbc : dot b c = 0) (habc : dot (omul a b) c = 0)
    (haa : dot a a = 1) (hbb : dot b b = 1) :
    smul (a, b) (c, partner a b c) = (ozero, ozero) := by
  obtain ⟨a0, a1, a2, a3, a4, a5, a6, a7⟩ := a
  obtain ⟨b0, b1, b2, b3, b4, b5, b6, b7⟩ := b
  obtain ⟨c0, c1, c2, c3, c4, c5, c6, c7⟩ := c
  simp only at ha0 hb0 hc0
  subst ha0 hb0 hc0
  simp only [dot, omul] at hab hac hbc habc haa hbb
  simp only [smul, partner, omul, conj, osub, oadd, ozero, Prod.mk.injEq, O.mk.injEq]
  refine ⟨⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩, ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩⟩
""")
gnames = ['hab', 'hac', 'hbc', 'habc', 'haa', 'hbb']
def lc(key):
    lam = certs[key]
    terms = [f"({lean_poly(l)}) * {g}" for l, g in zip(lam, gnames) if l != '0']
    return "linear_combination " + (' + '.join(terms) if terms else "(0:ℝ) * hab")
cases = []
for name in ('first', 'second'):
    for k in range(8):
        cases.append(f"  · {lc(name + str(k))}")
lines.append('\n'.join(cases) + '\n\nend SedenionReal\n')
open('/home/claude/bench/lean-real/SedenionReal.lean', 'w').write(''.join(lines))
print("written", len(certs), "certs")
