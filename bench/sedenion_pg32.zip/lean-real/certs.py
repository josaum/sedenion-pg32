import sympy as sp, torch, json, sys
sys.path.insert(0,'/home/claude/bench/pkg')
from sedenion_pg32 import tables
S,_,_=tables(); S=S.to(torch.int64).tolist()
def omul(x,y):
    out=[0]*8
    for i in range(8):
        for j in range(8):
            out[i^j]+= S[i][j]*x[i]*y[j]
    return [sp.expand(e) for e in out]
a=[0]+list(sp.symbols('a1:8')); b=[0]+list(sp.symbols('b1:8')); c=[0]+list(sp.symbols('c1:8'))
conj=lambda x:[x[0]]+[-t for t in x[1:]]
ab=omul(a,b); d=omul(omul(a,c),b)
first=[sp.expand(p-q) for p,q in zip(omul(a,c), omul(conj(d),b))]
second=[sp.expand(p+q) for p,q in zip(omul(d,a), omul(b,conj(c)))]
dot=lambda x,y: sum(x[i]*y[i] for i in range(1,8))
g=[dot(a,b), dot(a,c), dot(b,c), dot(ab,c), dot(a,a)-1, dot(b,b)-1]
vars_=a[1:]+b[1:]+c[1:]
mons=[sp.Integer(1)]+list(vars_)+[vars_[i]*vars_[j] for i in range(21) for j in range(i,21)]
certs={}
for name,comps in (("first",first),("second",second)):
  for k,f in enumerate(comps):
    if f==0: certs[f"{name}{k}"]=["0"]*6; continue
    coef=sp.symbols(f'l0:{6*len(mons)}')
    expr=f-sum(coef[i*len(mons)+m]*mons[m]*g[i] for i in range(6) for m in range(len(mons)))
    eqs=sp.Poly(sp.expand(expr),*vars_).coeffs()
    sol=sp.linsolve(eqs,coef)
    sol=list(sol)[0]; sol=[s.subs({cc:0 for cc in coef}) for s in sol]
    lam=[sp.expand(sum(sol[i*len(mons)+m]*mons[m] for m in range(len(mons)))) for i in range(6)]
    certs[f"{name}{k}"]=[str(l) for l in lam]
    print(name,k,[str(l) for l in lam],flush=True)
    json.dump(certs,open('/home/claude/bench/lean-real/certs.json','w'),indent=1)
