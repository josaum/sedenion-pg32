/**
 * @file sedenion_pg32_embedded.h
 * @brief Bare-Metal Zero-Heap 16D Cayley-Dickson Sedenion PG(3,2) DSP,
 *        SVD-Free Moreno Q1.14 Null-Steerer, 2-Tap XOR Pre-ADC Crossbar,
 *        and 2-Stage Quaternion Hinge Pulse/RSSI Peeler.
 *
 * Targets:
 *   1. Flipper Zero STM32WB55RG (ARM Cortex-M4F @ 64 MHz, FPv4-SP-D16 FPU)
 *   2. Flipper Wi-Fi Devboard ESP32-S2-WROVER (Xtensa LX7 @ 240 MHz)
 *
 * Memory Footprint:
 *   - 0 bytes heap (strictly stack/caller-allocated structs)
 *   - ~1.4 KB const RODATA in Flash
 */
#pragma once

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ==========================================================================
 * 1. Exact 16x16 Cayley-Dickson Sedenion Multiplication LUTs (512 B Flash)
 * ========================================================================== */

static const int8_t SED_MUL_SIGN[16][16] = {
    { 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1},
    { 1, -1,  1, -1,  1, -1, -1,  1,  1, -1, -1,  1, -1,  1,  1, -1},
    { 1, -1, -1,  1,  1,  1, -1, -1,  1,  1, -1, -1, -1, -1,  1,  1},
    { 1,  1, -1, -1,  1, -1,  1, -1,  1, -1,  1, -1, -1,  1, -1,  1},
    { 1, -1, -1, -1, -1,  1,  1,  1,  1,  1,  1,  1, -1, -1, -1, -1},
    { 1,  1, -1,  1, -1, -1, -1,  1,  1, -1,  1, -1,  1, -1,  1, -1},
    { 1,  1,  1, -1, -1,  1, -1, -1,  1, -1, -1,  1,  1, -1, -1,  1},
    { 1, -1,  1,  1, -1, -1,  1, -1,  1,  1, -1, -1,  1,  1, -1, -1},
    { 1, -1, -1, -1, -1, -1, -1, -1, -1,  1,  1,  1,  1,  1,  1,  1},
    { 1,  1, -1,  1, -1,  1,  1, -1, -1, -1, -1,  1, -1,  1,  1, -1},
    { 1,  1,  1, -1, -1, -1,  1,  1, -1,  1, -1, -1, -1, -1,  1,  1},
    { 1, -1,  1,  1, -1,  1, -1,  1, -1, -1,  1, -1, -1,  1, -1,  1},
    { 1,  1,  1,  1,  1, -1, -1, -1, -1,  1,  1,  1, -1, -1, -1, -1},
    { 1, -1,  1, -1,  1,  1,  1, -1, -1, -1,  1, -1,  1, -1,  1, -1},
    { 1, -1, -1,  1,  1, -1,  1,  1, -1, -1, -1,  1,  1, -1, -1,  1},
    { 1,  1, -1, -1,  1,  1, -1,  1, -1,  1, -1, -1,  1,  1, -1, -1}
};

static const uint8_t SED_MUL_IDX[16][16] = {
    { 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15},
    { 1,  0,  3,  2,  5,  4,  7,  6,  9,  8, 11, 10, 13, 12, 15, 14},
    { 2,  3,  0,  1,  6,  7,  4,  5, 10, 11,  8,  9, 14, 15, 12, 13},
    { 3,  2,  1,  0,  7,  6,  5,  4, 11, 10,  9,  8, 15, 14, 13, 12},
    { 4,  5,  6,  7,  0,  1,  2,  3, 12, 13, 14, 15,  8,  9, 10, 11},
    { 5,  4,  7,  6,  1,  0,  3,  2, 13, 12, 15, 14,  9,  8, 11, 10},
    { 6,  7,  4,  5,  2,  3,  0,  1, 14, 15, 12, 13, 10, 11,  8,  9},
    { 7,  6,  5,  4,  3,  2,  1,  0, 15, 14, 13, 12, 11, 10,  9,  8},
    { 8,  9, 10, 11, 12, 13, 14, 15,  0,  1,  2,  3,  4,  5,  6,  7},
    { 9,  8, 11, 10, 13, 12, 15, 14,  1,  0,  3,  2,  5,  4,  7,  6},
    {10, 11,  8,  9, 14, 15, 12, 13,  2,  3,  0,  1,  6,  7,  4,  5},
    {11, 10,  9,  8, 15, 14, 13, 12,  3,  2,  1,  0,  7,  6,  5,  4},
    {12, 13, 14, 15,  8,  9, 10, 11,  4,  5,  6,  7,  0,  1,  2,  3},
    {13, 12, 15, 14,  9,  8, 11, 10,  5,  4,  7,  6,  1,  0,  3,  2},
    {14, 15, 12, 13, 10, 11,  8,  9,  6,  7,  4,  5,  2,  3,  0,  1},
    {15, 14, 13, 12, 11, 10,  9,  8,  7,  6,  5,  4,  3,  2,  1,  0}
};

/* PG(3,2) 15 Hyperplanes certified by `inH omega i` (`parity4(omega & i) == 0` for omega = 1..15) */
static const uint8_t PG32_H_BLADES[15][7] = {
    {2,  4,  6,  8, 10, 12, 14}, /* H_1  (omega = 1)  */
    {1,  4,  5,  8,  9, 12, 13}, /* H_2  (omega = 2)  */
    {3,  4,  7,  8, 11, 12, 15}, /* H_3  (omega = 3)  */
    {1,  2,  3,  8,  9, 10, 11}, /* H_4  (omega = 4)  */
    {2,  5,  7,  8, 10, 13, 15}, /* H_5  (omega = 5)  */
    {1,  6,  7,  8,  9, 14, 15}, /* H_6  (omega = 6)  */
    {3,  5,  6,  8, 11, 13, 14}, /* H_7  (omega = 7)  */
    {1,  2,  3,  4,  5,  6,  7}, /* H_8  (omega = 8, Octonion core) */
    {2,  4,  6,  9, 11, 13, 15}, /* H_9  (omega = 9)  */
    {1,  4,  5, 10, 11, 14, 15}, /* H_10 (omega = 10) */
    {3,  4,  7,  9, 10, 13, 14}, /* H_11 (omega = 11) */
    {1,  2,  3, 12, 13, 14, 15}, /* H_12 (omega = 12) */
    {2,  5,  7,  9, 11, 12, 14}, /* H_13 (omega = 13) */
    {1,  6,  7, 10, 11, 12, 13}, /* H_14 (omega = 14) */
    {3,  5,  6,  9, 10, 12, 15}  /* H_15 (omega = 15) */
};

/* Primary W* zero-divisor nuller blade string for each of the 15 hyperplanes */
static const char* const PG32_WSTAR_LABELS[15] = {
    "e_4+e_10", "e_4-e_13", "e_4-e_15", "e_2+e_11", "e_2+e_15",
    "e_6-e_15", "e_5+e_14", "e_4-e_15", "e_4+e_15", "e_5+e_14",
    "e_4-e_13", "e_2+e_15", "e_5+e_14", "e_6-e_13", "e_5-e_12"
};

/* ==========================================================================
 * 2. Telemetry Output Structs (Zero-Heap)
 * ========================================================================== */

typedef struct {
    float kappa_s;            /* Normalized associator curvature [0..1] */
    float darpa_kappa_s;      /* DARPA [R, pi_O(R), e_8] curvature      */
    float mf_eff;             /* Binet-Cauchy matched filter eff [0..1] */
    float moreno_q14_db;      /* Q1.14 fixed-point null depth (dB)      */
    uint8_t fano_h_idx;       /* 1..15 index in PG(3,2)                 */
    uint8_t dom_lo_idx;       /* 1..7 octonion blade index              */
    uint8_t dom_hi_idx;       /* 9..15 sedenion blade index             */
    uint8_t moreno_seed_idx;  /* 1..7 canonical octonion seed e_k       */
    int8_t dom_sign;          /* +1 or -1                               */
    int16_t w_q14[16];        /* Quantized Q1.14 Moreno nuller blade    */
} SedenionAnalysisResult;

typedef struct {
    uint16_t raw_pairs;
    uint16_t cleaned_pairs;
    uint16_t glitches_coalesced;
    uint16_t hinge_projections;
    int32_t estimated_te_us;
    float pre_kappa_s;
    float post_kappa_s;
    float pre_mf_eff;
    float post_mf_eff;
    SedenionAnalysisResult dsp;
} SedenionPeelReport;

/* ==========================================================================
 * 3. Core Sedenion Multiplication, Associator & SVD-Free Moreno Q1.14 Nuller
 * ========================================================================== */

static inline void sedenion_mul_f32(const float x[16], const float y[16], float z[16]) {
    float out[16];
    for (int k = 0; k < 16; k++) {
        float acc = 0.0f;
        for (int j = 0; j < 16; j++) {
            uint8_t i = (uint8_t)(k ^ j);
            acc += (float)SED_MUL_SIGN[i][j] * x[i] * y[j];
        }
        out[k] = acc;
    }
    for (int k = 0; k < 16; k++) {
        z[k] = out[k];
    }
}

/**
 * @brief Fast 8D Octonion Subalgebra Product (64 ops vs 256 ops) for vectors in span{e_0..e_7}.
 */
static inline void sedenion_oct_mul_f32(const float x[16], const float y[16], float z[16]) {
    float out[8];
    for (int k = 0; k < 8; k++) {
        float acc = 0.0f;
        for (int j = 0; j < 8; j++) {
            uint8_t i = (uint8_t)(k ^ j);
            acc += (float)SED_MUL_SIGN[i][j] * x[i] * y[j];
        }
        out[k] = acc;
    }
    for (int k = 0; k < 8; k++) {
        z[k] = out[k];
    }
    for (int k = 8; k < 16; k++) {
        z[k] = 0.0f;
    }
}

/**
 * @brief Exact Q1.14 Fixed-Point Integer Sedenion Crossbar Product (0 floating-point drift).
 *        Certified by `q14_fixed_point_moreno_zero_lsb_identity`.
 */
static inline void sedenion_mul_q14_i16(
    const int16_t u_q14[16],
    const int16_t w_q14[16],
    int32_t out_q28[16]
) {
    for (int k = 0; k < 16; k++) {
        int32_t acc = 0;
        for (int j = 0; j < 16; j++) {
            uint8_t i = (uint8_t)(k ^ j);
            acc += (int32_t)SED_MUL_SIGN[i][j] * (int32_t)u_q14[i] * (int32_t)w_q14[j];
        }
        out_q28[k] = acc;
    }
}

/**
 * @brief Closed-Form O(1) Zero-Divisor Partner Synthesizer for U_J = e_a + s1 * e_b.
 *        Certified by `combinatorial_crossbar_336_global_optima`:
 *        for any c in {1..7} \ {a, b^8, a^(b^8)}, d = a ^ b ^ c and s2 = -s1 * eps(a,c) * eps(b,d).
 */
static inline uint8_t sedenion_find_null_partners_u8(
    uint8_t a,
    uint8_t b,
    int8_t s1,
    uint8_t c_out[4],
    uint8_t d_out[4],
    int8_t s2_out[4]
) {
    if (a < 1 || a > 7 || b < 9 || b > 15 || (b ^ 8U) == a) {
        return 0;
    }
    uint8_t b0 = (uint8_t)(b ^ 8U);
    uint8_t ab0 = (uint8_t)(a ^ b0);
    int8_t s = (s1 >= 0) ? 1 : -1;
    uint8_t n = 0;
    for (uint8_t c = 1; c <= 7 && n < 4; c++) {
        if (c == a || c == b0 || c == ab0) continue;
        uint8_t d = (uint8_t)(a ^ b ^ c);
        int8_t s2 = (int8_t)(-s * SED_MUL_SIGN[a][c] * SED_MUL_SIGN[b][d]);
        c_out[n] = c;
        d_out[n] = d;
        s2_out[n] = s2;
        n++;
    }
    return n;
}

/**
 * @brief Branchless 21-Wedge Fano-Line Pure Imaginary Octonion Cross Product (x x_O y).
 *        For orthogonal x, y in Im(O) (x[0] = y[0] = 0, <x, y> = 0), equals x *_O y
 *        with zero loops, zero branches, and zero table loads.
 */
static inline void sedenion_oct_cross_f32(const float x[16], const float y[16], float z[16]) {
    z[0] = 0.0f;
    z[1] =  (x[2] * y[3] - x[3] * y[2]) + (x[4] * y[5] - x[5] * y[4]) - (x[6] * y[7] - x[7] * y[6]);
    z[2] = -(x[1] * y[3] - x[3] * y[1]) + (x[4] * y[6] - x[6] * y[4]) + (x[5] * y[7] - x[7] * y[5]);
    z[3] =  (x[1] * y[2] - x[2] * y[1]) + (x[4] * y[7] - x[7] * y[4]) - (x[5] * y[6] - x[6] * y[5]);
    z[4] = -(x[1] * y[5] - x[5] * y[1]) - (x[2] * y[6] - x[6] * y[2]) - (x[3] * y[7] - x[7] * y[3]);
    z[5] =  (x[1] * y[4] - x[4] * y[1]) - (x[2] * y[7] - x[7] * y[2]) + (x[3] * y[6] - x[6] * y[3]);
    z[6] =  (x[1] * y[7] - x[7] * y[1]) + (x[2] * y[4] - x[4] * y[2]) - (x[3] * y[5] - x[5] * y[3]);
    z[7] = -(x[1] * y[6] - x[6] * y[1]) + (x[2] * y[5] - x[5] * y[2]) + (x[3] * y[4] - x[4] * y[3]);
    for (uint8_t k = 8; k < 16; k++) {
        z[k] = 0.0f;
    }
}

/**
 * @brief Native Sedenion Associator [R, pi_O(R), e_8] = (R * pi_O(R)) * e_8 - R * (pi_O(R) * e_8)
 *
 * By the Lean-certified theorems `sparse_42term_fano_native_associator_equivalence` and
 * `differential_fano_wedge_associator_identity`:
 *   [a + b e_8, a, e_8] = -2 (a x_O b) = -2 (a x_O (b - a))
 * supported strictly on Im(O) (indices 1..7).
 * Evaluating the 21 Fano-line wedges against the Hinge difference d_i = b_i - a_i = r[i + 8] - r[i]
 * guarantees bit-exact IEEE-754 zero (0.0f) under FMA whenever r[i + 8] == r[i] (Hinge lock),
 * eliminates catastrophic cancellation near the 4D Quaternion Hinge, and executes in 21 branchless
 * 2x2 determinants with zero table lookups.
 */
static inline void sedenion_native_associator_f32(const float r[16], float assoc[16]) {
    const float d1 = r[9]  - r[1];
    const float d2 = r[10] - r[2];
    const float d3 = r[11] - r[3];
    const float d4 = r[12] - r[4];
    const float d5 = r[13] - r[5];
    const float d6 = r[14] - r[6];
    const float d7 = r[15] - r[7];

    assoc[0] = 0.0f;
    assoc[1] = -2.0f * ( (r[2] * d3 - r[3] * d2) + (r[4] * d5 - r[5] * d4) - (r[6] * d7 - r[7] * d6));
    assoc[2] = -2.0f * (-(r[1] * d3 - r[3] * d1) + (r[4] * d6 - r[6] * d4) + (r[5] * d7 - r[7] * d5));
    assoc[3] = -2.0f * ( (r[1] * d2 - r[2] * d1) + (r[4] * d7 - r[7] * d4) - (r[5] * d6 - r[6] * d5));
    assoc[4] = -2.0f * (-(r[1] * d5 - r[5] * d1) - (r[2] * d6 - r[6] * d2) - (r[3] * d7 - r[7] * d3));
    assoc[5] = -2.0f * ( (r[1] * d4 - r[4] * d1) - (r[2] * d7 - r[7] * d2) + (r[3] * d6 - r[6] * d3));
    assoc[6] = -2.0f * ( (r[1] * d7 - r[7] * d1) + (r[2] * d4 - r[4] * d2) - (r[3] * d5 - r[5] * d3));
    assoc[7] = -2.0f * (-(r[1] * d6 - r[6] * d1) + (r[2] * d5 - r[5] * d2) + (r[3] * d4 - r[4] * d3));
    for (uint8_t k = 8; k < 16; k++) {
        assoc[k] = 0.0f;
    }
}

/**
 * @brief 2-Tap XOR Sign-Flip Pre-ADC Crossbar: y[n] = (x[n] - s_k * x[n - delay]) / sqrt(2)
 */
static inline void sedenion_pre_adc_crossbar_2tap(
    const float* x,
    float* y,
    size_t len,
    size_t delay_samples,
    int8_t xor_sign
) {
    const float inv_sqrt2 = 0.70710678f;
    const float s = (xor_sign >= 0) ? 1.0f : -1.0f;
    for (size_t i = 0; i < len; i++) {
        if (i < delay_samples) {
            y[i] = x[i] * inv_sqrt2;
        } else {
            y[i] = (x[i] - s * x[i - delay_samples]) * inv_sqrt2;
        }
    }
}

/**
 * @brief Full 16D Sedenion Analysis + SVD-Free Moreno Q1.14 Nuller
 *        Executes in ~3.5 us on STM32WB55 Cortex-M4F (64 MHz) and ~0.8 us on ESP32-S2 (240 MHz).
 */
static inline void sedenion_analyze_state_f32(
    const float r_in[16],
    SedenionAnalysisResult* out
) {
    float r_norm_sq = 0.0f;
    for (int i = 0; i < 16; i++) {
        r_norm_sq += r_in[i] * r_in[i];
    }
    float r_norm = sqrtf(r_norm_sq);
    float r[16];
    if (r_norm > 1e-7f) {
        float inv = 1.0f / r_norm;
        for (int i = 0; i < 16; i++) r[i] = r_in[i] * inv;
    } else {
        for (int i = 0; i < 16; i++) r[i] = 0.0f;
        r[1] = 0.70710678f;
        r[10] = 0.70710678f;
    }

    float oct_energy = 0.0f;
    float twist_energy = 0.0f;
    float dot_ot = 0.0f;
    for (int i = 1; i <= 7; i++) {
        oct_energy += r[i] * r[i];
        twist_energy += r[i + 8] * r[i + 8];
        dot_ot += r[i] * r[i + 8];
    }

    float assoc[16];
    sedenion_native_associator_f32(r, assoc);
    float assoc_sq = 0.0f;
    for (int i = 1; i <= 7; i++) {
        assoc_sq += assoc[i] * assoc[i];
    }

    float denom = 4.0f * oct_energy * twist_energy;
    float kappa_sq = (denom > 1e-12f) ? (assoc_sq / denom) : 0.0f;
    if (kappa_sq < 0.0f) kappa_sq = 0.0f;
    if (kappa_sq > 1.0f) kappa_sq = 1.0f;
    float kappa = sqrtf(kappa_sq);

    float total_energy = oct_energy + twist_energy;
    float darpa_kappa = (total_energy > 1e-12f) ? (sqrtf(assoc_sq) / total_energy) : 0.0f;
    if (darpa_kappa > 1.0f) darpa_kappa = 1.0f;

    /* Exact Binet-Cauchy / Lagrange Matched-Filter Efficiency:
     * eta_MF = <a,b>^2 / (||a||^2 ||b||^2) = 1 - ||a x_O b||^2 / (||a||^2 ||b||^2) = 1 - kappa_S^2.
     * Using 1.0f - kappa_sq avoids float32 rounding loss near 1.0f so kappa_S == 0 => mf_eff == 1.0f. */
    float mf_eff = 1.0f - kappa_sq;
    if (mf_eff < 0.0f) mf_eff = 0.0f;
    if (mf_eff > 1.0f) mf_eff = 1.0f;

    /* Precompute |r[i]| once for dominant blade and PG(3,2) hyperplane classification */
    float abs_r[16];
    abs_r[0] = fabsf(r[0]);
    abs_r[8] = fabsf(r[8]);

    uint8_t dom_lo = 1;
    float max_lo = -1.0f;
    for (uint8_t i = 1; i <= 7; i++) {
        float v = fabsf(r[i]);
        abs_r[i] = v;
        if (v > max_lo) {
            max_lo = v;
            dom_lo = i;
        }
    }
    uint8_t dom_hi = 9;
    float max_hi = -1.0f;
    for (uint8_t i = 9; i <= 15; i++) {
        float v = fabsf(r[i]);
        abs_r[i] = v;
        if (v > max_hi) {
            max_hi = v;
            dom_hi = i;
        }
    }
    if ((dom_hi ^ 8U) == dom_lo) {
        dom_hi = (uint8_t)(9U + (dom_lo % 7U));
        if ((dom_hi ^ 8U) == dom_lo) {
            dom_hi = (uint8_t)(9U + ((dom_lo + 1U) % 7U));
        }
    }
    int8_t dom_sign = ((r[dom_lo] * r[dom_hi]) >= 0.0f) ? 1 : -1;

    /* Classify into one of the 15 PG(3,2) hyperplanes */
    uint8_t best_h = 0;
    float best_h_energy = -1.0f;
    for (uint8_t h = 0; h < 15; h++) {
        const uint8_t* blades = PG32_H_BLADES[h];
        float e = abs_r[blades[0]] + abs_r[blades[1]] + abs_r[blades[2]] +
                  abs_r[blades[3]] + abs_r[blades[4]] + abs_r[blades[5]] + abs_r[blades[6]];
        if (e > best_h_energy) {
            best_h_energy = e;
            best_h = h;
        }
    }

    /* SVD-Free Moreno Nuller W = (c + ((a_hat * c) * b_hat) e_8) / sqrt(2) */
    float a_hat[16], b_hat[16];
    float a_sq = oct_energy;
    for (int i = 0; i < 16; i++) {
        a_hat[i] = 0.0f;
        b_hat[i] = 0.0f;
    }
    for (int i = 1; i <= 7; i++) {
        a_hat[i] = r[i];
        b_hat[i] = r[i + 8];
    }
    if (a_sq > 1e-12f) {
        float inv_a = 1.0f / sqrtf(a_sq);
        for (int i = 1; i <= 7; i++) a_hat[i] *= inv_a;
    } else {
        a_hat[dom_lo] = 1.0f;
    }

    /* Orthonormalize b_hat against a_hat to form the Moreno special pair */
    float dot_ab = 0.0f;
    for (int i = 1; i <= 7; i++) dot_ab += a_hat[i] * b_hat[i];
    float b_sq = 0.0f;
    for (int i = 1; i <= 7; i++) {
        b_hat[i] -= dot_ab * a_hat[i];
        b_sq += b_hat[i] * b_hat[i];
    }
    if (b_sq > 1e-9f) {
        float inv_b = 1.0f / sqrtf(b_sq);
        for (int i = 1; i <= 7; i++) b_hat[i] *= inv_b;
    } else {
        uint8_t fallback_idx = (fabsf(a_hat[1]) > 0.7f) ? 2U : 1U;
        for (int i = 1; i <= 7; i++) b_hat[i] = (i == fallback_idx) ? 1.0f : 0.0f;
        float proj2 = a_hat[fallback_idx];
        b_sq = 0.0f;
        for (int i = 1; i <= 7; i++) {
            b_hat[i] -= proj2 * a_hat[i];
            b_sq += b_hat[i] * b_hat[i];
        }
        float inv_b = (b_sq > 1e-12f) ? (1.0f / sqrtf(b_sq)) : 1.0f;
        for (int i = 1; i <= 7; i++) b_hat[i] *= inv_b;
    }

    /* Quaternion subalgebra H = span(1, a_hat, b_hat, q3 = a_hat * b_hat).
     * Since a_hat, b_hat in Im(O) are orthogonal, a_hat * b_hat == a_hat x_O b_hat. */
    float q3[16];
    sedenion_oct_cross_f32(a_hat, b_hat, q3);
    float q3_sq = 0.0f;
    for (int i = 1; i <= 7; i++) q3_sq += q3[i] * q3[i];
    if (q3_sq > 1e-12f) {
        float inv_q3 = 1.0f / sqrtf(q3_sq);
        for (int i = 1; i <= 7; i++) q3[i] *= inv_q3;
    }

    /* Deterministic canonical seed selection in H^perp */
    uint8_t best_seed = 4;
    float best_proj_sq = -1.0f;
    for (uint8_t k = 1; k <= 7; k++) {
        float da = a_hat[k];
        float db = b_hat[k];
        float dq = q3[k];
        float p_sq = 1.0f - da * da - db * db - dq * dq;
        if (p_sq > best_proj_sq + 1e-7f) {
            best_proj_sq = p_sq;
            best_seed = k;
        }
    }

    float c_best[16];
    for (int i = 0; i < 16; i++) c_best[i] = 0.0f;
    float da = a_hat[best_seed];
    float db = b_hat[best_seed];
    float dq = q3[best_seed];
    float c_sq = 0.0f;
    for (int i = 1; i <= 7; i++) {
        c_best[i] = ((i == best_seed) ? 1.0f : 0.0f) - da * a_hat[i] - db * b_hat[i] - dq * q3[i];
        c_sq += c_best[i] * c_best[i];
    }
    float inv_c = (c_sq > 1e-12f) ? (1.0f / sqrtf(c_sq)) : 1.0f;
    for (int i = 1; i <= 7; i++) c_best[i] *= inv_c;

    /* Compute d = (a_hat * c_best) * b_hat in 8D Octonion subalgebra.
     * Both products are between orthogonal pure-imaginary octonions, so cross product is exact. */
    float ac[16], d_vec[16];
    sedenion_oct_cross_f32(a_hat, c_best, ac);
    sedenion_oct_cross_f32(ac, b_hat, d_vec);

    /* Construct W = (c_best + d_vec * e_8) / sqrt(2) and quantize to Q1.14 */
    const float inv_sqrt2 = 0.70710678f;
    float w_q14_f[16];
    float z_jam[16];
    for (int i = 0; i < 16; i++) {
        float wi = 0.0f;
        if (i >= 1 && i <= 7) wi = c_best[i] * inv_sqrt2;
        else if (i >= 9 && i <= 15) wi = d_vec[i - 8] * inv_sqrt2;
        int32_t q = (int32_t)lrintf(wi * 16384.0f);
        if (q > 32767) q = 32767;
        if (q < -32768) q = -32768;
        out->w_q14[i] = (int16_t)q;
        w_q14_f[i] = (float)q / 16384.0f;

        if (i >= 1 && i <= 7) z_jam[i] = a_hat[i] * inv_sqrt2;
        else if (i >= 9 && i <= 15) z_jam[i] = b_hat[i - 8] * inv_sqrt2;
        else z_jam[i] = 0.0f;
    }

    float leak[16];
    sedenion_mul_f32(z_jam, w_q14_f, leak);
    float leak_sq = 0.0f;
    for (int i = 0; i < 16; i++) leak_sq += leak[i] * leak[i];
    float q14_db = (leak_sq > 1e-12f) ? (-10.0f * log10f(leak_sq)) : 120.0f;

    out->kappa_s = kappa;
    out->darpa_kappa_s = darpa_kappa;
    out->mf_eff = mf_eff;
    out->moreno_q14_db = q14_db;
    out->fano_h_idx = (uint8_t)(best_h + 1);
    out->dom_lo_idx = dom_lo;
    out->dom_hi_idx = dom_hi;
    out->moreno_seed_idx = best_seed;
    out->dom_sign = dom_sign;
}

/* ==========================================================================
 * 4. 2-Stage Sedenion Pulse Peeler & 4D Quaternion Hinge Conditioner
 *    Works on Sub-GHz (.sub), Infrared (.ir), LF-RFID (.raw), & HF-NFC
 * ========================================================================== */

static inline void sedenion_build_state_from_pairs_i32(
    const int32_t* high_us,
    const int32_t* low_us,
    size_t count,
    int32_t te_us,
    float r_out[16]
) {
    for (int i = 0; i < 16; i++) r_out[i] = 0.0f;
    if (count == 0) {
        r_out[1] = 0.70710678f;
        r_out[10] = 0.70710678f;
        return;
    }
    int64_t te64 = (te_us > 0) ? (int64_t)te_us : 350;
    float te = (float)te64;
    float inv_te = 1.0f / te;
    int64_t max_sync_us = te64 * 8 + (te64 / 2);

    for (size_t i = 0; i < count; i++) {
        uint8_t slot = (uint8_t)((i % 7) + 1);
        float rh = (float)high_us[i] * inv_te;
        if (rh < 0.0f) rh = 0.0f;
        /* Marks above 8.5 * TE are long sync/header marks (e.g. NEC 9000 us = 16 * TE);
         * fold onto the 8.0 * TE ceiling so rh == qh == 8.0 without artificial residual. */
        if (rh > 8.5f) rh = 8.0f;
        float qh = roundf(rh);
        if (qh < 1.0f) qh = 1.0f;
        if (qh > 8.0f) qh = 8.0f;

        if ((int64_t)low_us[i] > max_sync_us) {
            /* Inter-frame sync gap: only evaluate HIGH mark against its quantized TE template */
            float q_err = fabsf(rh - qh);
            r_out[slot] += rh * 0.5f;
            r_out[8 + slot] += qh * 0.5f;
            if (q_err > 1e-4f) {
                uint8_t orth_slot = (uint8_t)(8 + ((slot % 7) + 1));
                r_out[orth_slot] += q_err * 1.5f;
            }
            continue;
        }

        float rl = (float)low_us[i] * inv_te;
        if (rl < 0.0f) rl = 0.0f;
        if (rl > 8.5f) rl = 8.0f;
        float ql = roundf(rl);
        if (ql < 1.0f) ql = 1.0f;
        if (ql > 8.0f) ql = 8.0f;

        /* Embed measured envelope in Im(O) (1..7) and quantized Hinge template in Im(O)*e_8 (9..15).
         * By [R, pi_O(R), e_8] = -2(a x_O b), when (rh, rl) == (qh, ql), a == b and kappa_S == 0. */
        float meas = (qh != ql) ? fabsf(rh - rl) : ((rh + rl) * 0.5f);
        float tmpl = (qh != ql) ? fabsf(qh - ql) : ((qh + ql) * 0.5f);
        float q_err = fabsf(rh - qh) + fabsf(rl - ql);

        r_out[slot] += meas;
        r_out[8 + slot] += tmpl;
        if (q_err > 1e-4f) {
            uint8_t orth_slot = (uint8_t)(8 + ((slot % 7) + 1));
            r_out[orth_slot] += q_err * 1.5f;
        }
    }
}

/**
 * @brief In-place 2-Stage Sedenion Glitch Coalescer + 4D Quaternion Hinge Conditioner
 *        Operates strictly within caller-supplied arrays (0 bytes heap).
 *
 * @param high_us       In/Out array of HIGH pulse durations in microseconds
 * @param low_us        In/Out array of LOW space durations in microseconds
 * @param count         Number of input pairs
 * @param te_hint_us    Nominal TE in us (0 to auto-estimate)
 * @param report        Output telemetry report (may be NULL)
 * @return              New number of conditioned pairs (<= count)
 */
static inline void sedenion_estimate_cycle_invariant_te_and_bias_i32(
    const int32_t* high_us,
    const int32_t* low_us,
    size_t count,
    int32_t te_hint_us,
    int32_t* te_out,
    int32_t* bias_out
) {
    int64_t acc_min = 0;
    size_t n_min = 0;
    int64_t raw_sum_acc = 0;
    size_t n_cand = 0;

    for (size_t i = 0; i < count; i++) {
        int32_t h = high_us[i];
        int32_t l = low_us[i];
        int32_t m = (h < l) ? h : l;
        if (m >= 90 && m <= 2500) {
            acc_min += (int64_t)m;
            n_min++;
        }
        if (h >= 110 && l >= 110 && h <= 5000 && l <= 5000) {
            int64_t s = (int64_t)h + (int64_t)l;
            if (s <= 5000) {
                raw_sum_acc += s;
                n_cand++;
            }
        }
    }

    int32_t min_te = (n_min > 0) ? (int32_t)(acc_min / (int64_t)n_min) : 350;
    int32_t te = (te_hint_us > 0) ? te_hint_us : min_te;
    int32_t slicer_bias = 0;

    if (n_cand >= 6) {
        int64_t raw_s_mean = raw_sum_acc / (int64_t)n_cand;
        int64_t inlier_s_acc = 0;
        int64_t inlier_h_acc = 0;
        size_t n_inlier = 0;
        for (size_t i = 0; i < count; i++) {
            int32_t h = high_us[i];
            int32_t l = low_us[i];
            if (h >= 110 && l >= 110 && h <= 5000 && l <= 5000) {
                int64_t s = (int64_t)h + (int64_t)l;
                int64_t diff = (s >= raw_s_mean) ? (s - raw_s_mean) : (raw_s_mean - s);
                if (s <= 5000 && diff * 100 <= raw_s_mean * 18) {
                    inlier_s_acc += s;
                    inlier_h_acc += (int64_t)h;
                    n_inlier++;
                }
            }
        }

        if (n_inlier >= 6 && n_inlier * 100 >= n_cand * 70) {
            int64_t s_mean = (inlier_s_acc + (int64_t)(n_inlier / 2)) / (int64_t)n_inlier;
            int64_t h_mean = inlier_h_acc / (int64_t)n_inlier;
            int64_t lo_h_acc = 0;
            size_t n_lo = 0;
            int64_t hi_h_acc = 0;
            int64_t hi_l_acc = 0;
            size_t n_hi = 0;

            for (size_t i = 0; i < count; i++) {
                int32_t h = high_us[i];
                int32_t l = low_us[i];
                if (h >= 110 && l >= 110 && h <= 5000 && l <= 5000) {
                    int64_t s = (int64_t)h + (int64_t)l;
                    int64_t diff = (s >= raw_s_mean) ? (s - raw_s_mean) : (raw_s_mean - s);
                    if (s <= 5000 && diff * 100 <= raw_s_mean * 18) {
                        if ((int64_t)h < h_mean) {
                            lo_h_acc += (int64_t)h;
                            n_lo++;
                        } else {
                            hi_h_acc += (int64_t)h;
                            hi_l_acc += (int64_t)l;
                            n_hi++;
                        }
                    }
                }
            }

            if (n_lo >= 2 && n_hi >= 2) {
                int64_t h_lo = lo_h_acc / (int64_t)n_lo;
                int64_t h_hi = hi_h_acc / (int64_t)n_hi;
                int64_t l_hi = hi_l_acc / (int64_t)n_hi;
                int64_t dh = (h_hi > h_lo) ? (h_hi - h_lo) : 0;

                if (te_hint_us <= 0) {
                    if (dh * 100 >= s_mean * 41) {
                        te = (int32_t)((s_mean + 2) / 4);
                    } else if (dh * 100 >= s_mean * 22) {
                        te = (int32_t)((s_mean + 1) / 3);
                    }
                }

                int64_t te_pos = (te > 4) ? (int64_t)te : 4;
                if (dh * 100 >= te_pos * 65) {
                    int64_t raw_b = ((h_lo - te_pos) + (te_pos - l_hi)) / 2;
                    int64_t abs_b = (raw_b >= 0) ? raw_b : -raw_b;
                    if (abs_b * 100 > te_pos * 12) {
                        int64_t max_b = (te_pos * 68) / 100;
                        if (raw_b > max_b) raw_b = max_b;
                        if (raw_b < -max_b) raw_b = -max_b;
                        slicer_bias = (int32_t)raw_b;
                    }
                }
            }
        }
    }

    if (te < 4) te = 4;
    *te_out = te;
    *bias_out = slicer_bias;
}

static inline size_t sedenion_peel_pulse_pairs_i32(
    int32_t* high_us,
    int32_t* low_us,
    size_t count,
    int32_t te_hint_us,
    SedenionPeelReport* report
) {
    if (count == 0) return 0;

    /* 1. Estimate TE and comparator DC slicer bias via cycle-period invariants */
    int32_t te = 350;
    int32_t slicer_bias = 0;
    sedenion_estimate_cycle_invariant_te_and_bias_i32(
        high_us, low_us, count, te_hint_us, &te, &slicer_bias);
    int64_t te64 = (int64_t)te;
    int64_t max_sync_us = te64 * 8 + (te64 / 2);

    float r_pre[16];
    SedenionAnalysisResult pre_res;
    sedenion_build_state_from_pairs_i32(high_us, low_us, count, te, r_pre);
    sedenion_analyze_state_f32(r_pre, &pre_res);

    /* 2. Stage 1: Coalesce sub-TE non-associative glitches (< 0.42 * TE), guarded against
     *    coalescing legitimate DC-shrunk pulses (TE - |slicer_bias|) */
    int64_t abs_bias = (slicer_bias >= 0) ? (int64_t)slicer_bias : -(int64_t)slicer_bias;
    int64_t shrunk_pulse = (te64 > abs_bias) ? (te64 - abs_bias) : 0;
    int64_t base_glitch = (te64 * 42) / 100;
    int64_t safe_glitch = (shrunk_pulse * 72) / 100;
    int64_t min_glitch = (te64 * 18) / 100;
    if (min_glitch < 3) min_glitch = 3;
    int64_t glitch_thresh = (base_glitch < safe_glitch) ? base_glitch : safe_glitch;
    if (glitch_thresh < min_glitch) glitch_thresh = min_glitch;

    uint16_t glitches = 0;
    size_t out_n = 0;
    size_t idx = 0;
    while (idx < count) {
        int64_t h = (high_us[idx] > 0) ? (int64_t)high_us[idx] : 0;
        int64_t l = (low_us[idx] > 0) ? (int64_t)low_us[idx] : 0;
        /* Iteratively merge consecutive short low-dropout splits inside a mark pulse */
        while (l < glitch_thresh && (idx + 1) < count) {
            int64_t nh = (high_us[idx + 1] > 0) ? (int64_t)high_us[idx + 1] : 0;
            int64_t nl = (low_us[idx + 1] > 0) ? (int64_t)low_us[idx + 1] : 0;
            h += l + nh;
            if (h > 2000000000LL) h = 2000000000LL;
            l = nl;
            glitches++;
            idx++;
        }
        if ((h < glitch_thresh || l < glitch_thresh) && out_n > 0) {
            /* Fold glitch energy into previous pulse's LOW gap */
            int64_t prev_l = (int64_t)low_us[out_n - 1] + h + l;
            if (prev_l > 2000000000LL) prev_l = 2000000000LL;
            low_us[out_n - 1] = (int32_t)prev_l;
            glitches++;
            idx++;
        } else if (h < glitch_thresh && out_n == 0 && (idx + 1) < count) {
            /* Leading pre-frame noise spike: strip before first valid mark */
            glitches++;
            idx++;
        } else {
            if (h > 2000000000LL) h = 2000000000LL;
            if (l > 2000000000LL) l = 2000000000LL;
            high_us[out_n] = (int32_t)h;
            low_us[out_n] = (int32_t)l;
            out_n++;
            idx++;
        }
    }

    /* 3. Stage 2: 4D Associative Quaternion Hinge Projection with slicer-bias de-skewing */
    uint16_t hinges = 0;
    for (size_t i = 0; i < out_n; i++) {
        int64_t h = (high_us[i] > 0) ? (int64_t)high_us[i] : 0;
        int64_t l = (low_us[i] > 0) ? (int64_t)low_us[i] : 0;
        int64_t h_deskew = h - (int64_t)slicer_bias;
        int64_t l_deskew = l + (int64_t)slicer_bias;
        if (h_deskew < 1) h_deskew = 1;
        if (l_deskew < 1) l_deskew = 1;
        if (l_deskew > 2000000000LL) l_deskew = 2000000000LL;

        if (l > max_sync_us) {
            /* Inter-frame sync/preamble gap: snap de-skewed HIGH to nearest integer TE in [1..8] */
            int64_t qh = (h_deskew + (te64 / 2)) / te64;
            if (qh < 1) qh = 1;
            if (qh <= 8) {
                int32_t nh = (int32_t)(qh * te64);
                int32_t nl = (int32_t)l_deskew;
                if (nh != high_us[i] || nl != low_us[i]) {
                    high_us[i] = nh;
                    low_us[i] = nl;
                    hinges++;
                }
            }
            continue;
        }
        int64_t tot = h + l;
        int64_t tot_q = (tot + (te64 / 2)) / te64;
        int64_t rem = tot - tot_q * te64;
        if (rem < 0) rem = -rem;

        /* Within 45% of a canonical (1:3), (3:1), (1:2), (2:1), or (1:1) duty symbol */
        if (rem * 100 <= te64 * 45 && (tot_q == 2 || tot_q == 3 || tot_q == 4)) {
            int32_t nh = (int32_t)h;
            int32_t nl = (int32_t)l;
            if (tot_q == 4) {
                nh = (h_deskew < l_deskew) ? te : (3 * te);
                nl = (h_deskew < l_deskew) ? (3 * te) : te;
            } else if (tot_q == 3) {
                nh = (h_deskew < l_deskew) ? te : (2 * te);
                nl = (h_deskew < l_deskew) ? (2 * te) : te;
            } else {
                nh = te;
                nl = te;
            }
            if (nh != high_us[i] || nl != low_us[i]) {
                high_us[i] = nh;
                low_us[i] = nl;
                hinges++;
            }
        } else {
            int64_t qh = (h_deskew + (te64 / 2)) / te64;
            int64_t ql = (l_deskew + (te64 / 2)) / te64;
            if (qh < 1) qh = 1;
            if (ql < 1) ql = 1;
            int32_t nh = (qh <= 8) ? (int32_t)(qh * te64) : high_us[i];
            int32_t nl = (ql <= 8) ? (int32_t)(ql * te64) : low_us[i];
            if (nh != high_us[i] || nl != low_us[i]) {
                high_us[i] = nh;
                low_us[i] = nl;
                hinges++;
            }
        }
    }

    float r_post[16];
    SedenionAnalysisResult post_res;
    sedenion_build_state_from_pairs_i32(high_us, low_us, out_n, te, r_post);
    sedenion_analyze_state_f32(r_post, &post_res);

    if (report) {
        report->raw_pairs = (uint16_t)count;
        report->cleaned_pairs = (uint16_t)out_n;
        report->glitches_coalesced = glitches;
        report->hinge_projections = hinges;
        report->estimated_te_us = te;
        report->pre_kappa_s = pre_res.kappa_s;
        report->post_kappa_s = post_res.kappa_s;
        report->pre_mf_eff = pre_res.mf_eff;
        report->post_mf_eff = post_res.mf_eff;
        report->dsp = post_res;
    }
    return out_n;
}

/* ==========================================================================
 * 5. Embedded 802.11 Wi-Fi RSSI Peeler & Probe Collision Gate (ESP32-S2)
 * ========================================================================== */

/**
 * @brief Peels >9 dB non-associative multipath RSSI spikes from an int8_t ring buffer
 *        and computes the 16D Sedenion PG(3,2) state for an 802.11 station.
 */
static inline uint8_t sedenion_peel_wifi_rssi_i8(
    int8_t* rssi_hist,
    uint8_t count,
    uint16_t seq_num,
    uint16_t ie_hash,
    SedenionAnalysisResult* out_dsp
) {
    uint8_t peeled = 0;
    uint8_t n = (count > 16) ? 16 : count;

    if (n >= 3) {
        for (uint8_t i = 1; i + 1 < n; i++) {
            int16_t prev = rssi_hist[i - 1];
            int16_t cur  = rssi_hist[i];
            int16_t next = rssi_hist[i + 1];
            int16_t neighbor_med = (prev + next) / 2;
            int16_t dev = cur - neighbor_med;
            if (dev < 0) dev = -dev;
            int16_t span = prev - next;
            if (span < 0) span = -span;
            if (dev > 9 && span <= 8) {
                rssi_hist[i] = (int8_t)neighbor_med;
                peeled++;
            }
        }
    }

    if (out_dsp) {
        float r[16];
        for (int i = 0; i < 16; i++) r[i] = 0.0f;
        for (uint8_t i = 0; i < n; i++) {
            uint8_t slot = (uint8_t)(1 + (i % 7));
            float meas = (float)(rssi_hist[i] + 100) * 0.1f;
            if (meas < 0.5f) meas = 0.5f;
            uint8_t prev_idx = (i > 0) ? (i - 1) : 0;
            uint8_t next_idx = (i + 1 < n) ? (i + 1) : (n - 1);
            float smooth = 0.5f * (float)rssi_hist[i] + 0.25f * (float)(rssi_hist[prev_idx] + rssi_hist[next_idx]);
            float tmpl = (smooth + 100.0f) * 0.1f;
            if (tmpl < 0.5f) tmpl = 0.5f;
            r[slot] += meas;
            r[8 + slot] += tmpl;
        }
        uint8_t seq_slot = (uint8_t)(1 + ((seq_num ^ ie_hash) % 7));
        r[seq_slot] += 0.20f;
        r[8 + seq_slot] += 0.20f;
        sedenion_analyze_state_f32(r, out_dsp);
    }
    return peeled;
}

/* ==========================================================================
 * 6. Pure-Memory 125 kHz LF-RFID Cycle Conditioner & DMA Underflow Guard
 *    Certified by `lfrfid_pg32_dma_underflow_immune` (8 us carrier grid)
 * ========================================================================== */

/**
 * @brief Snaps a single 125 kHz LF-RFID (pulse_us, duration_us) pair onto the
 *        8 us carrier grid (>= 8 us DMA safety invariant) and 64 us harmonic grid.
 */
static inline void sedenion_lfrfid_snap_cycle_u32(
    uint32_t prev_p,
    uint32_t prev_d,
    uint32_t* p_out,
    uint32_t* d_out,
    uint16_t* hinges
) {
    static const int32_t k_rfid_harmonics[11] = {
        64, 128, 192, 256, 320, 384, 448, 512, 640, 768, 1024
    };
    uint32_t raw_neg = (prev_d > prev_p) ? (prev_d - prev_p) : 8U;
    uint32_t neg_out = ((raw_neg + 4U) / 8U) * 8U;
    if (neg_out < 8U) neg_out = 8U;

    int32_t snapped_d = 0;
    for (size_t h_idx = 0; h_idx < 11; h_idx++) {
        int32_t diff = (int32_t)prev_d - k_rfid_harmonics[h_idx];
        if (diff < 0) diff = -diff;
        if (diff <= 24) {
            snapped_d = k_rfid_harmonics[h_idx];
            break;
        }
    }
    uint32_t po = 0, do_val = 0;
    if (snapped_d > 0 && (uint32_t)snapped_d >= neg_out + 8U) {
        do_val = (uint32_t)snapped_d;
        po = do_val - neg_out;
        if (do_val != prev_d || po != prev_p) (*hinges)++;
    } else {
        po = ((prev_p + 4U) / 8U) * 8U;
        if (po < 8U) po = 8U;
        do_val = po + neg_out;
        if (do_val < 64U) {
            do_val = 64U;
            if (neg_out >= 64U) neg_out = 8U;
            po = do_val - neg_out;
        }
        if (do_val != prev_d || po != prev_p) (*hinges)++;
    }
    *p_out = po;
    *d_out = do_val;
}

static inline size_t sedenion_lfrfid_condition_cycles_u32(
    uint32_t* pulse_us,
    uint32_t* duration_us,
    size_t count,
    int32_t te_us,
    SedenionPeelReport* report
) {
    if (count == 0) return 0;
    int32_t grid_us = (te_us >= 64) ? 64 : ((te_us > 0) ? te_us : 64);

    /* Embed LF-RFID cycles using the dual-grid observable:
     *   high = duration_us (evaluated on the 64 us harmonic grid)
     *   low  = (duration_us - pulse_us) * 8 (8 us carrier space scaled onto the 64 us grid)
     * This ensures both pre- and post-conditioning states are evaluated with the exact same
     * algebraic observable and already-conditioned cycles satisfy pre_kappa_s == post_kappa_s == 0. */
    int32_t pre_h[64], pre_l[64];
    size_t pre_n = (count < 64) ? count : 64;
    for (size_t i = 0; i < pre_n; i++) {
        uint32_t p = pulse_us[i];
        uint32_t d = duration_us[i];
        uint32_t neg = (d > p) ? (d - p) : 0U;
        pre_h[i] = (int32_t)((d <= 200000000U) ? d : 200000000U);
        pre_l[i] = (int32_t)(((neg <= 25000000U) ? neg : 25000000U) * 8U);
    }
    float r_pre[16];
    SedenionAnalysisResult pre_res;
    sedenion_build_state_from_pairs_i32(pre_h, pre_l, pre_n, grid_us, r_pre);
    sedenion_analyze_state_f32(r_pre, &pre_res);

    uint16_t glitches = 0;
    uint16_t hinges = 0;
    size_t out_n = 0;
    bool has_prev = false;
    uint32_t prev_p = 0;
    uint32_t prev_d = 0;
    uint32_t pending_p = 0;
    uint32_t pending_d = 0;

    for (size_t i = 0; i < count; i++) {
        uint32_t p = pulse_us[i];
        uint32_t d = duration_us[i];
        if (d == 0 && p == 0) continue;
        if (d < 48U || p < 8U) {
            if (has_prev) {
                prev_p += p;
                prev_d += d;
            } else {
                pending_p += p;
                pending_d += d;
            }
            glitches++;
            continue;
        }
        p += pending_p;
        d += pending_d;
        pending_p = 0;
        pending_d = 0;
        if (has_prev) {
            uint32_t p_out = 0, d_out = 0;
            sedenion_lfrfid_snap_cycle_u32(prev_p, prev_d, &p_out, &d_out, &hinges);
            pulse_us[out_n] = p_out;
            duration_us[out_n] = d_out;
            out_n++;
        }
        prev_p = (p >= 8U) ? p : 8U;
        prev_d = (d >= prev_p + 8U) ? d : (prev_p + 8U);
        has_prev = true;
    }

    if (!has_prev && (pending_d > 0 || pending_p > 0)) {
        prev_p = (pending_p >= 8U) ? pending_p : 8U;
        prev_d = (pending_d >= prev_p + 8U) ? pending_d : (prev_p + 8U);
        has_prev = true;
    }

    if (has_prev) {
        uint32_t p_out = 0, d_out = 0;
        sedenion_lfrfid_snap_cycle_u32(prev_p, prev_d, &p_out, &d_out, &hinges);
        pulse_us[out_n] = p_out;
        duration_us[out_n] = d_out;
        out_n++;
    }

    int32_t post_h[64], post_l[64];
    size_t post_n = (out_n < 64) ? out_n : 64;
    for (size_t i = 0; i < post_n; i++) {
        uint32_t p = pulse_us[i];
        uint32_t d = duration_us[i];
        uint32_t neg = (d > p) ? (d - p) : 0U;
        post_h[i] = (int32_t)d;
        post_l[i] = (int32_t)(neg * 8U);
    }
    float r_post[16];
    SedenionAnalysisResult post_res;
    sedenion_build_state_from_pairs_i32(post_h, post_l, post_n, grid_us, r_post);
    sedenion_analyze_state_f32(r_post, &post_res);

    if (report) {
        report->raw_pairs = (uint16_t)count;
        report->cleaned_pairs = (uint16_t)out_n;
        report->glitches_coalesced = glitches;
        report->hinge_projections = hinges;
        report->estimated_te_us = grid_us;
        report->pre_kappa_s = pre_res.kappa_s;
        report->post_kappa_s = post_res.kappa_s;
        report->pre_mf_eff = pre_res.mf_eff;
        report->post_mf_eff = post_res.mf_eff;
        report->dsp = post_res;
    }
    return out_n;
}

/* ==========================================================================
 * 7. Alternativity-Defect N_u Calculus, SVD-Free MMSE, Co-Axial & [16,8,6]_3 FEC
 *    Runs on bare-metal Cortex-M4F with 0 heap and 0 LUT RAM
 * ========================================================================== */

static const uint8_t SED_TERNARY_16_8_6_PARITY[8][8] = {
    {1, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 1, 2, 1, 1, 2},
    {2, 1, 2, 2, 2, 2, 1, 1},
    {2, 2, 1, 2, 2, 1, 2, 1},
    {2, 1, 1, 1, 2, 2, 2, 2},
    {2, 2, 1, 2, 1, 2, 1, 2},
    {2, 2, 2, 1, 1, 2, 2, 1},
    {2, 1, 2, 2, 1, 1, 2, 2}
};

static inline void sedenion_oct_mul8_f32(const float a[8], const float b[8], float out[8]) {
    float tmp[8];
    for (int k = 0; k < 8; k++) {
        float acc = 0.0f;
        for (int j = 0; j < 8; j++) {
            uint8_t i = (uint8_t)(k ^ j);
            acc += (float)SED_MUL_SIGN[i][j] * a[i] * b[j];
        }
        tmp[k] = acc;
    }
    for (int k = 0; k < 8; k++) out[k] = tmp[k];
}

static inline void sedenion_oct_assoc8_f32(
    const float a[8],
    const float b[8],
    const float c[8],
    float out[8]
) {
    float ab[8], lhs[8], bc[8], rhs[8];
    sedenion_oct_mul8_f32(a, b, ab);
    sedenion_oct_mul8_f32(ab, c, lhs);
    sedenion_oct_mul8_f32(b, c, bc);
    sedenion_oct_mul8_f32(a, bc, rhs);
    for (int k = 0; k < 8; k++) out[k] = lhs[k] - rhs[k];
}

static inline void sedenion_alternativity_defect_f32(
    const float u[16],
    const float y[16],
    float out[16]
) {
    float abd[8], abc[8];
    sedenion_oct_assoc8_f32(&u[0], &u[8], &y[8], abd);
    sedenion_oct_assoc8_f32(&u[0], &u[8], &y[0], abc);
    for (int k = 0; k < 8; k++) {
        out[k] = abd[k];
        out[8 + k] = -abc[k];
    }
}

static inline bool sedenion_mmse_equalize_f32(
    const float u[16],
    const float y[16],
    float lambda_reg,
    float out[16]
) {
    float s = 0.0f;
    for (int i = 0; i < 16; i++) s += u[i] * u[i];
    float a_sq = 0.0f, b_sq = 0.0f, ab = 0.0f;
    for (int k = 1; k < 8; k++) {
        a_sq += u[k] * u[k];
        b_sq += u[k + 8] * u[k + 8];
        ab += u[k] * u[k + 8];
    }
    float lam_sq = a_sq * b_sq - ab * ab;
    if (lam_sq < 0.0f) lam_sq = 0.0f;
    float tau = s + ((lambda_reg > 0.0f) ? lambda_reg : 0.0f);
    float den = tau * tau - 4.0f * lam_sq;
    if (tau <= 1e-12f || fabsf(den) <= 1e-10f) return false;

    float uc[16];
    uc[0] = u[0];
    for (int i = 1; i < 16; i++) uc[i] = -u[i];

    float z0[16], z1[16], z2[16];
    sedenion_mul_f32(uc, y, z0);
    sedenion_alternativity_defect_f32(u, z0, z1);
    sedenion_alternativity_defect_f32(u, z1, z2);

    float c0 = 1.0f / tau;
    float c1 = 1.0f / den;
    float c2 = 1.0f / (tau * den);
    for (int i = 0; i < 16; i++) {
        out[i] = c0 * z0[i] + c1 * z1[i] + c2 * z2[i];
    }
    return true;
}

static inline void sedenion_apply_cascade_f32(
    const float r[16],
    const float w1[16],
    const float w2[16],
    float out[16]
) {
    float stg1[16];
    sedenion_mul_f32(r, w1, stg1);
    sedenion_mul_f32(stg1, w2, out);
}

static inline void sedenion_hurwitz_radon_spread_f32(
    const float sym9[9],
    const float key16[16],
    float out16[16]
) {
    float u[16];
    for (int i = 0; i < 9; i++) u[i] = sym9[i];
    for (int i = 9; i < 16; i++) u[i] = 0.0f;
    sedenion_mul_f32(u, key16, out16);
}

static inline bool sedenion_hurwitz_radon_despread_f32(
    const float chips16[16],
    const float key16[16],
    float out9[9]
) {
    float ksq = 0.0f;
    for (int i = 0; i < 16; i++) ksq += key16[i] * key16[i];
    if (ksq <= 1e-12f) return false;
    float inv = 1.0f / ksq;
    for (int i = 0; i < 9; i++) {
        float dot = 0.0f;
        for (int j = 0; j < 16; j++) {
            uint8_t k = (uint8_t)(i ^ j);
            dot += (float)SED_MUL_SIGN[i][j] * key16[j] * chips16[k];
        }
        out9[i] = dot * inv;
    }
    return true;
}

static inline void sedenion_encode_ternary_16_8_6(
    const uint8_t msg8[8],
    uint8_t cw16[16]
) {
    for (int i = 0; i < 8; i++) cw16[i] = (uint8_t)(msg8[i] % 3U);
    for (int j = 0; j < 8; j++) {
        uint16_t acc = 0;
        for (int i = 0; i < 8; i++) {
            acc = (uint16_t)(acc + (uint16_t)cw16[i] * (uint16_t)SED_TERNARY_16_8_6_PARITY[i][j]);
        }
        cw16[8 + j] = (uint8_t)(acc % 3U);
    }
}

static inline uint8_t sedenion_ternary_col_u8(uint8_t row, uint8_t col) {
    if (col < 8U) return (row == col) ? 1U : 0U;
    return SED_TERNARY_16_8_6_PARITY[row][col - 8U];
}

static inline int8_t sedenion_decode_ternary_16_8_6(
    const uint8_t rx16[16],
    uint8_t msg8_out[8]
) {
    uint8_t clean[16];
    for (uint8_t i = 0; i < 16U; i++) clean[i] = (uint8_t)(rx16[i] % 3U);

    uint8_t syn[8];
    bool nz = false;
    for (uint8_t r = 0; r < 8U; r++) {
        uint16_t acc = clean[r];
        for (uint8_t j = 0; j < 8U; j++) {
            acc = (uint16_t)(acc + (uint16_t)SED_TERNARY_16_8_6_PARITY[r][j] * (uint16_t)clean[8U + j]);
        }
        syn[r] = (uint8_t)(acc % 3U);
        if (syn[r] != 0U) nz = true;
    }
    if (!nz) {
        for (uint8_t i = 0; i < 8U; i++) msg8_out[i] = clean[i];
        return 0;
    }

    for (uint8_t c1 = 0; c1 < 16U; c1++) {
        for (uint8_t v1 = 1U; v1 <= 2U; v1++) {
            bool ok = true;
            for (uint8_t r = 0; r < 8U; r++) {
                if ((uint8_t)((sedenion_ternary_col_u8(r, c1) * v1) % 3U) != syn[r]) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                clean[c1] = (uint8_t)((clean[c1] + 3U - v1) % 3U);
                for (uint8_t i = 0; i < 8U; i++) msg8_out[i] = clean[i];
                return 1;
            }
        }
    }

    for (uint8_t c1 = 0; c1 < 15U; c1++) {
        for (uint8_t c2 = (uint8_t)(c1 + 1U); c2 < 16U; c2++) {
            for (uint8_t v1 = 1U; v1 <= 2U; v1++) {
                for (uint8_t v2 = 1U; v2 <= 2U; v2++) {
                    bool ok = true;
                    for (uint8_t r = 0; r < 8U; r++) {
                        uint8_t es = (uint8_t)(
                            (sedenion_ternary_col_u8(r, c1) * v1 + sedenion_ternary_col_u8(r, c2) * v2) % 3U);
                        if (es != syn[r]) {
                            ok = false;
                            break;
                        }
                    }
                    if (ok) {
                        clean[c1] = (uint8_t)((clean[c1] + 3U - v1) % 3U);
                        clean[c2] = (uint8_t)((clean[c2] + 3U - v2) % 3U);
                        for (uint8_t i = 0; i < 8U; i++) msg8_out[i] = clean[i];
                        return 2;
                    }
                }
            }
        }
    }
    return -1;
}

/* ==========================================================================
 * 8. Pontryagin Maximum Principle: argmax_w H(x, p, J, w) over S and PG(3,2)
 * ========================================================================== */

static inline float sedenion_pontryagin_hamiltonian_f32(
    const float x[16],
    const float p[16],
    const float jam[16],
    const float w[16],
    float gamma_jam,
    float rho_effort
) {
    float xw[16], jw[16];
    sedenion_mul_f32(x, w, xw);
    sedenion_mul_f32(jam, w, jw);
    float pxw = 0.0f, jw_sq = 0.0f, w_sq = 0.0f;
    for (int i = 0; i < 16; i++) {
        pxw += p[i] * xw[i];
        jw_sq += jw[i] * jw[i];
        w_sq += w[i] * w[i];
    }
    float g = (gamma_jam > 0.0f) ? gamma_jam : 0.0f;
    float r = (rho_effort > 0.0f) ? rho_effort : 0.0f;
    return pxw - 0.5f * g * jw_sq - 0.5f * r * w_sq;
}

static inline bool sedenion_pontryagin_max_control_f32(
    const float x[16],
    const float p[16],
    const float jam[16],
    float gamma_jam,
    float rho_effort,
    float w_out[16],
    float* h_max_out
) {
    float g = (gamma_jam > 0.0f) ? gamma_jam : 0.0f;
    float r = (rho_effort > 0.0f) ? rho_effort : 0.0f;
    float s = 0.0f;
    for (int i = 0; i < 16; i++) s += jam[i] * jam[i];
    float a_sq = 0.0f, b_sq = 0.0f, ab = 0.0f;
    for (int k = 1; k < 8; k++) {
        a_sq += jam[k] * jam[k];
        b_sq += jam[k + 8] * jam[k + 8];
        ab += jam[k] * jam[k + 8];
    }
    float lam_sq = a_sq * b_sq - ab * ab;
    if (lam_sq < 0.0f) lam_sq = 0.0f;
    float tau = r + g * s;
    float den = tau * tau - 4.0f * g * g * lam_sq;
    if (tau <= 1e-12f || den <= 1e-12f) return false;

    float xc[16], psi[16], n1[16], n2[16];
    xc[0] = x[0];
    for (int i = 1; i < 16; i++) xc[i] = -x[i];
    sedenion_mul_f32(xc, p, psi);
    sedenion_alternativity_defect_f32(jam, psi, n1);
    sedenion_alternativity_defect_f32(jam, n1, n2);

    float c0 = 1.0f / tau;
    float c1 = g / den;
    float c2 = (g * g) / (tau * den);
    for (int i = 0; i < 16; i++) {
        w_out[i] = c0 * psi[i] + c1 * n1[i] + c2 * n2[i];
    }
    if (h_max_out) {
        *h_max_out = sedenion_pontryagin_hamiltonian_f32(x, p, jam, w_out, g, r);
    }
    return true;
}

static inline bool sedenion_moore_penrose_zd_f32(
    const float u[16],
    const float y[16],
    float out[16]
) {
    float s = 0.0f;
    for (int i = 0; i < 16; i++) s += u[i] * u[i];
    if (s <= 1e-12f) return false;

    float uc[16], z0[16], z1[16], z2[16];
    uc[0] = u[0];
    for (int i = 1; i < 16; i++) uc[i] = -u[i];
    sedenion_mul_f32(uc, y, z0);
    sedenion_alternativity_defect_f32(u, z0, z1);
    sedenion_alternativity_defect_f32(u, z1, z2);

    float inv_s = 1.0f / s;
    float c1 = -0.25f * inv_s * inv_s;
    float c2 = -0.75f * inv_s * inv_s * inv_s;
    for (int i = 0; i < 16; i++) {
        out[i] = inv_s * z0[i] + c1 * z1[i] + c2 * z2[i];
    }
    return true;
}

static inline bool sedenion_project_ker_zd_f32(
    const float u[16],
    const float x[16],
    float out[16]
) {
    float s = 0.0f;
    for (int i = 0; i < 16; i++) s += u[i] * u[i];
    if (s <= 1e-12f) return false;

    float n1[16], n2[16];
    sedenion_alternativity_defect_f32(u, x, n1);
    sedenion_alternativity_defect_f32(u, n1, n2);
    float scale = 1.0f / (2.0f * s * s);
    for (int i = 0; i < 16; i++) {
        out[i] = scale * (n2[i] + s * n1[i]);
    }
    return true;
}

static inline bool sedenion_pontryagin_zd_sphere_f32(
    const float x[16],
    const float p[16],
    const float jam_zd[16],
    float w_out[16],
    float* h_star_out
) {
    float xc[16], psi[16], proj[16];
    xc[0] = x[0];
    for (int i = 1; i < 16; i++) xc[i] = -x[i];
    sedenion_mul_f32(xc, p, psi);
    if (!sedenion_project_ker_zd_f32(jam_zd, psi, proj)) return false;

    float nrm_sq = 0.0f;
    for (int i = 0; i < 16; i++) nrm_sq += proj[i] * proj[i];
    if (nrm_sq <= 1e-12f) return false;
    float nrm = sqrtf(nrm_sq);
    float inv_nrm = 1.0f / nrm;
    for (int i = 0; i < 16; i++) w_out[i] = proj[i] * inv_nrm;
    if (h_star_out) *h_star_out = nrm;
    return true;
}

/**
 * @brief Discrete 168-blade Pre-ADC Analog Crossbar Pontryagin Bang-Bang Selector:
 *        argmax_{w in B_84^{+-}} H(x, p, J, w).
 *        Outputs the optimal 7-bit blade_id (0..83), overall sign (+1/-1),
 *        unit-norm blade vector w_out[16], and optimal Hamiltonian value.
 */
static inline uint8_t sedenion_pontryagin_bang_bang_168_f32(
    const float x[16],
    const float p[16],
    const float jam[16],
    float gamma_jam,
    float rho_effort,
    int8_t* sign_out,
    float w_out[16],
    float* h_best_out
) {
    float xc[16], psi[16];
    xc[0] = x[0];
    for (int i = 1; i < 16; i++) xc[i] = -x[i];
    sedenion_mul_f32(xc, p, psi);

    const float inv_sqrt2 = 0.70710678f;
    const float g = (gamma_jam > 0.0f) ? gamma_jam : 0.0f;
    const float r = (rho_effort > 0.0f) ? rho_effort : 0.0f;

    uint8_t best_id = 0;
    int8_t best_pol = 1;
    float best_h = -1.0e30f;
    uint8_t blade_idx = 0;

    for (uint8_t a = 1; a <= 7; a++) {
        for (uint8_t b = 9; b <= 15; b++) {
            if ((b ^ 8U) == a) continue;
            for (int s_idx = 0; s_idx < 2; s_idx++) {
                float sb = (s_idx == 0) ? 1.0f : -1.0f;
                /* Compute ||jam * w||_2^2 using 2-sparse right blade w = (e_a + sb*e_b)/sqrt(2) */
                float jw_sq = 0.0f;
                for (uint8_t k = 0; k < 16; k++) {
                    uint8_t ia = (uint8_t)(k ^ a);
                    uint8_t ib = (uint8_t)(k ^ b);
                    float term = (float)SED_MUL_SIGN[ia][a] * jam[ia]
                               + sb * (float)SED_MUL_SIGN[ib][b] * jam[ib];
                    jw_sq += 0.5f * term * term;
                }
                float lin = (psi[a] + sb * psi[b]) * inv_sqrt2;
                float pen = 0.5f * g * jw_sq + 0.5f * r;
                /* Evaluate +w and -w simultaneously */
                float h_pos =  lin - pen;
                float h_neg = -lin - pen;
                if (h_pos > best_h) {
                    best_h = h_pos;
                    best_id = blade_idx;
                    best_pol = 1;
                    if (w_out) {
                        for (int i = 0; i < 16; i++) w_out[i] = 0.0f;
                        w_out[a] = inv_sqrt2;
                        w_out[b] = sb * inv_sqrt2;
                    }
                }
                if (h_neg > best_h) {
                    best_h = h_neg;
                    best_id = blade_idx;
                    best_pol = -1;
                    if (w_out) {
                        for (int i = 0; i < 16; i++) w_out[i] = 0.0f;
                        w_out[a] = -inv_sqrt2;
                        w_out[b] = -sb * inv_sqrt2;
                    }
                }
                blade_idx++;
            }
        }
    }
    if (sign_out) *sign_out = best_pol;
    if (h_best_out) *h_best_out = best_h;
    return best_id;
}

/* ==========================================================================
 * 9. Aut(S) = G_2 x S_3 Phase Automorphism & Sextic Invariant J_3(u)
 * ========================================================================== */

static inline void sedenion_aut_s3_phase_f32(
    const float u[16],
    int k_sector,
    bool reflect,
    float out[16]
) {
    float base[16];
    for (int i = 0; i < 16; i++) base[i] = u[i];
    if (reflect) {
        for (int i = 8; i < 16; i++) base[i] = -base[i];
    }
    int km = ((k_sector % 3) + 3) % 3;
    float c = (km == 0) ? 1.0f : -0.5f;
    float s = (km == 0) ? 0.0f : ((km == 1) ? 0.8660254f : -0.8660254f);
    out[0] = base[0];
    out[8] = base[8];
    for (int idx = 1; idx < 8; idx++) {
        float ak = base[idx];
        float bk = base[idx + 8];
        out[idx] = c * ak - s * bk;
        out[idx + 8] = s * ak + c * bk;
    }
}

static inline float sedenion_g2_s3_j3_invariant_f32(const float u[16]) {
    float a_sq = 0.0f, b_sq = 0.0f, ab = 0.0f;
    for (int k = 1; k < 8; k++) {
        a_sq += u[k] * u[k];
        b_sq += u[k + 8] * u[k + 8];
        ab += u[k] * u[k + 8];
    }
    float qr = a_sq - b_sq;
    float qi = 2.0f * ab;
    float q_abs = sqrtf(qr * qr + qi * qi);
    if (q_abs <= 1e-12f) return 0.0f;
    float re_q3 = qr * (qr * qr - 3.0f * qi * qi);
    float j3 = re_q3 / (q_abs * q_abs * q_abs);
    if (j3 > 1.0f) j3 = 1.0f;
    if (j3 < -1.0f) j3 = -1.0f;
    return j3;
}


#ifdef __cplusplus
}
#endif
