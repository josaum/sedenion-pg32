// sedenion_pg32_rust.rs — Native ARM64 NEON Sedenion PG(3,2) & SVD-Free Moreno Nuller Kernel
// Directly implements the Lean 4.35.0 kernel-verified formalization in:
//   /Users/josaum/projects/v3sp3r/proofs/MaxwellExterior.lean (§5)
// Compile via:
//   rustc --crate-type cdylib -C opt-level=3 -C target-cpu=native -C lto=fat -C codegen-units=1 \
//     /Users/josaum/projects/v3sp3r/scripts/sedenion_pg32_rust.rs \
//     -o /Users/josaum/projects/v3sp3r/scripts/libsedenion_pg32.dylib

use std::slice;

pub const EPS_T: [[f64; 16]; 16] = [
    [1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.],
    [1., -1., 1., -1., 1., -1., -1., 1., 1., -1., -1., 1., -1., 1., 1., -1.],
    [1., -1., -1., 1., 1., 1., -1., -1., 1., 1., -1., -1., -1., -1., 1., 1.],
    [1., 1., -1., -1., 1., -1., 1., -1., 1., -1., 1., -1., -1., 1., -1., 1.],
    [1., -1., -1., -1., -1., 1., 1., 1., 1., 1., 1., 1., -1., -1., -1., -1.],
    [1., 1., -1., 1., -1., -1., -1., 1., 1., -1., 1., -1., 1., -1., 1., -1.],
    [1., 1., 1., -1., -1., 1., -1., -1., 1., -1., -1., 1., 1., -1., -1., 1.],
    [1., -1., 1., 1., -1., -1., 1., -1., 1., 1., -1., -1., 1., 1., -1., -1.],
    [1., -1., -1., -1., -1., -1., -1., -1., -1., 1., 1., 1., 1., 1., 1., 1.],
    [1., 1., -1., 1., -1., 1., 1., -1., -1., -1., -1., 1., -1., 1., 1., -1.],
    [1., 1., 1., -1., -1., -1., 1., 1., -1., 1., -1., -1., -1., -1., 1., 1.],
    [1., -1., 1., 1., -1., 1., -1., 1., -1., -1., 1., -1., -1., 1., -1., 1.],
    [1., 1., 1., 1., 1., -1., -1., -1., -1., 1., 1., 1., -1., -1., -1., -1.],
    [1., -1., 1., -1., 1., 1., 1., -1., -1., -1., 1., -1., 1., -1., 1., -1.],
    [1., -1., -1., 1., 1., -1., 1., 1., -1., -1., -1., 1., 1., -1., -1., 1.],
    [1., 1., -1., -1., 1., 1., -1., 1., -1., 1., -1., -1., 1., 1., -1., -1.],
];

pub const FANO_H_INDICES: [[usize; 7]; 15] = [
    [2, 4, 6, 8, 10, 12, 14], // H_1
    [1, 4, 5, 8, 9, 12, 13],  // H_2
    [3, 4, 7, 8, 11, 12, 15], // H_3
    [1, 2, 3, 8, 9, 10, 11],  // H_4
    [2, 5, 7, 8, 10, 13, 15], // H_5
    [1, 6, 7, 8, 9, 14, 15],  // H_6
    [3, 5, 6, 8, 11, 13, 14], // H_7
    [1, 2, 3, 4, 5, 6, 7],    // H_8 (Octonion core)
    [2, 4, 6, 9, 11, 13, 15], // H_9
    [1, 4, 5, 10, 11, 14, 15],// H_10
    [3, 4, 7, 9, 10, 13, 14], // H_11
    [1, 2, 3, 12, 13, 14, 15],// H_12
    [2, 5, 7, 9, 11, 12, 14], // H_13
    [1, 6, 7, 10, 11, 12, 13],// H_14
    [3, 5, 6, 9, 10, 12, 15], // H_15
];

#[inline(always)]
pub fn sed_mul_inner(u: &[f64; 16], v: &[f64; 16]) -> [f64; 16] {
    let mut out = [0.0; 16];
    for k in 0..16 {
        let mut acc = 0.0;
        for j in 0..16 {
            let i = k ^ j;
            acc += EPS_T[i][j] * u[i] * v[j];
        }
        out[k] = acc;
    }
    out
}

#[inline(always)]
pub fn oct_mul_inner(x: &[f64; 16], y: &[f64; 16]) -> [f64; 16] {
    let mut out = [0.0; 16];
    for k in 0..8 {
        let mut acc = 0.0;
        for j in 0..8 {
            let i = k ^ j;
            acc += EPS_T[i][j] * x[i] * y[j];
        }
        out[k] = acc;
    }
    out
}

#[inline(always)]
pub fn oct_cross_pure_inner(x: &[f64; 16], y: &[f64; 16]) -> [f64; 16] {
    // Branchless 21-Wedge Fano-Line Pure Imaginary Octonion Cross Product (x x_O y)
    let mut out = [0.0; 16];
    out[1] =  (x[2] * y[3] - x[3] * y[2]) + (x[4] * y[5] - x[5] * y[4]) - (x[6] * y[7] - x[7] * y[6]);
    out[2] = -(x[1] * y[3] - x[3] * y[1]) + (x[4] * y[6] - x[6] * y[4]) + (x[5] * y[7] - x[7] * y[5]);
    out[3] =  (x[1] * y[2] - x[2] * y[1]) + (x[4] * y[7] - x[7] * y[4]) - (x[5] * y[6] - x[6] * y[5]);
    out[4] = -(x[1] * y[5] - x[5] * y[1]) - (x[2] * y[6] - x[6] * y[2]) - (x[3] * y[7] - x[7] * y[3]);
    out[5] =  (x[1] * y[4] - x[4] * y[1]) - (x[2] * y[7] - x[7] * y[2]) + (x[3] * y[6] - x[6] * y[3]);
    out[6] =  (x[1] * y[7] - x[7] * y[1]) + (x[2] * y[4] - x[4] * y[2]) - (x[3] * y[5] - x[5] * y[3]);
    out[7] = -(x[1] * y[6] - x[6] * y[1]) + (x[2] * y[5] - x[5] * y[2]) + (x[3] * y[4] - x[4] * y[3]);
    out
}

#[inline(always)]
pub fn sed_mul_e8_inner(u: &[f64; 16]) -> [f64; 16] {
    let mut out = [0.0; 16];
    for k in 0..16 {
        let i = k ^ 8;
        out[k] = EPS_T[i][8] * u[i];
    }
    out
}

#[inline(always)]
pub fn native_associator_inner(u: &[f64; 16]) -> [f64; 16] {
    // Certified by `SedenionDSP.native_associator_moreno_curvature_dichotomy`,
    // `SedenionDSP.sparse_42term_fano_native_associator_equivalence`, and
    // `SedenionDSP.differential_fano_wedge_associator_identity`:
    // `[R, pi_O(R), e_8] = -2(a x_O b) = -2(a x_O (b - a))`
    // Evaluating the 21 Fano-line wedges against `d_i = u[i + 8] - u[i]` guarantees
    // bit-exact IEEE-754 zero (0.0) under FMA whenever `u[i + 8] == u[i]`.
    let d1 = u[9]  - u[1];
    let d2 = u[10] - u[2];
    let d3 = u[11] - u[3];
    let d4 = u[12] - u[4];
    let d5 = u[13] - u[5];
    let d6 = u[14] - u[6];
    let d7 = u[15] - u[7];

    let mut out = [0.0; 16];
    out[1] = -2.0 * ( (u[2] * d3 - u[3] * d2) + (u[4] * d5 - u[5] * d4) - (u[6] * d7 - u[7] * d6));
    out[2] = -2.0 * (-(u[1] * d3 - u[3] * d1) + (u[4] * d6 - u[6] * d4) + (u[5] * d7 - u[7] * d5));
    out[3] = -2.0 * ( (u[1] * d2 - u[2] * d1) + (u[4] * d7 - u[7] * d4) - (u[5] * d6 - u[6] * d5));
    out[4] = -2.0 * (-(u[1] * d5 - u[5] * d1) - (u[2] * d6 - u[6] * d2) - (u[3] * d7 - u[7] * d3));
    out[5] = -2.0 * ( (u[1] * d4 - u[4] * d1) - (u[2] * d7 - u[7] * d2) + (u[3] * d6 - u[6] * d3));
    out[6] = -2.0 * ( (u[1] * d7 - u[7] * d1) + (u[2] * d4 - u[4] * d2) - (u[3] * d5 - u[5] * d3));
    out[7] = -2.0 * (-(u[1] * d6 - u[6] * d1) + (u[2] * d5 - u[5] * d2) + (u[3] * d4 - u[4] * d3));
    out
}

#[inline(always)]
fn dot7(x: &[f64; 16], y: &[f64; 16]) -> f64 {
    let mut s = 0.0;
    for i in 1..8 {
        s += x[i] * y[i];
    }
    s
}

#[inline(always)]
fn norm7(x: &[f64; 16]) -> f64 {
    dot7(x, x).max(0.0).sqrt()
}

#[inline(always)]
fn sed_norm_sq(x: &[f64; 16]) -> f64 {
    let mut s = 0.0;
    for i in 0..16 {
        s += x[i] * x[i];
    }
    s
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_mul_c(
    u_ptr: *const f64,
    v_ptr: *const f64,
    out_ptr: *mut f64,
) {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let v: &[f64; 16] = &*(v_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    *out = sed_mul_inner(u, v);
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_native_associator_c(
    u_ptr: *const f64,
    out_ptr: *mut f64,
) {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    *out = native_associator_inner(u);
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_pre_adc_crossbar_c(
    u_ptr: *const f64,
    c: usize,
    d: usize,
    s_d: f64,
    out_ptr: *mut f64,
) {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    let inv_sqrt2 = std::f64::consts::FRAC_1_SQRT_2;
    for k in 0..16 {
        let ic = k ^ (c & 15);
        let id = k ^ (d & 15);
        out[k] = inv_sqrt2 * (EPS_T[ic][c & 15] * u[ic] + s_d * EPS_T[id][d & 15] * u[id]);
    }
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_kappa_c(u_ptr: *const f64) -> f64 {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let mut oct_energy = 0.0;
    let mut twist_energy = 0.0;
    for i in 1..8 {
        oct_energy += u[i] * u[i];
        twist_energy += u[i + 8] * u[i + 8];
    }
    let assoc = native_associator_inner(u);
    let assoc_norm_sq = sed_norm_sq(&assoc);
    let denom = 4.0 * oct_energy * twist_energy;
    if denom > 1e-9 {
        (assoc_norm_sq / denom).sqrt().min(1.0)
    } else {
        0.0
    }
}

/// Complete single-call Sedenion PG(3,2) + Continuous SVD-Free Moreno Nuller evaluation.
/// `out_metrics` (8 x f64):
///   [0] assoc_norm_sq
///   [1] kappa_s
///   [2] darpa_kappa_s
///   [3] moreno_seed_proj_norm
///   [4] moreno_fp64_null_db
///   [5] moreno_q14_null_db
///   [6] moreno_sig_gain_db
///   [7] q3_orthogonality_err
/// `out_ints` (6 x i32):
///   [0] best_seed_idx (1..7)
///   [1] a_dom (1..7)
///   [2] b_dom (9..15)
///   [3] b_partner (9..15)
///   [4] s1 (+1 or -1)
///   [5] best_omega (1..15)
#[no_mangle]
pub unsafe extern "C" fn sedenion_full_analyze_c(
    u_ptr: *const f64,
    include_moreno: i32,
    out_metrics_ptr: *mut f64,
    out_ints_ptr: *mut i32,
) {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let out_m = slice::from_raw_parts_mut(out_metrics_ptr, 8);
    let out_i = slice::from_raw_parts_mut(out_ints_ptr, 6);

    let mut oct_energy = 0.0;
    let mut twist_energy = 0.0;
    for i in 1..8 {
        oct_energy += u[i] * u[i];
        twist_energy += u[i + 8] * u[i + 8];
    }

    let assoc = native_associator_inner(u);
    let assoc_norm_sq = sed_norm_sq(&assoc);
    let denom = 4.0 * oct_energy * twist_energy;
    let kappa_s = if denom > 1e-9 {
        (assoc_norm_sq / denom).sqrt().min(1.0)
    } else {
        0.0
    };
    let total_energy = oct_energy + twist_energy;
    let darpa_kappa_s = if total_energy > 1e-9 {
        (assoc_norm_sq.sqrt() / total_energy).min(1.0)
    } else {
        0.0
    };

    let mut best_norm = 0.0;
    let mut fp64_null_db = 0.0;
    let mut q14_null_db = 0.0;
    let mut sig_gain_db = 0.0;
    let mut q3_err = 0.0;
    let mut best_seed_idx: i32 = 4;

    if include_moreno != 0 {
        // Continuous SVD-Free Moreno Nuller (Section III-A of Agourakis 2026)
        let mut a = [0.0; 16];
        let mut b0 = [0.0; 16];
        for k in 1..8 {
            a[k] = u[k];
            b0[k] = u[k ^ 8];
        }
        let mut na = oct_energy.max(0.0).sqrt();
        if na < 1e-12 {
            a[1] = 1.0;
            na = 1.0;
        }
        let inv_na = 1.0 / na;
        let mut a_tilde = [0.0; 16];
        for k in 1..8 {
            a_tilde[k] = a[k] * inv_na;
        }

        let proj_ab = dot7(&b0, &a_tilde);
        let mut b_orth = [0.0; 16];
        for k in 1..8 {
            b_orth[k] = b0[k] - proj_ab * a_tilde[k];
        }
        let mut nb = norm7(&b_orth);
        if nb < 1e-9 {
            let fallback_idx = if a_tilde[1].abs() > 0.7 { 2 } else { 1 };
            b_orth = [0.0; 16];
            b_orth[fallback_idx] = 1.0;
            let proj2 = a_tilde[fallback_idx];
            for k in 1..8 {
                b_orth[k] = b_orth[k] - proj2 * a_tilde[k];
            }
            nb = norm7(&b_orth);
        }
        let inv_nb = 1.0 / nb;
        let mut b_tilde = [0.0; 16];
        for k in 1..8 {
            b_tilde[k] = b_orth[k] * inv_nb;
        }

        let mut r_jam = [0.0; 16];
        let mut r_sig = [0.0; 16];
        for k in 1..8 {
            r_jam[k] = a_tilde[k];
            r_jam[k + 8] = b_tilde[k];
            r_sig[k] = a_tilde[k];
            r_sig[k + 8] = -b_tilde[k];
        }

        // Theorem 1: q3 = -0.5 * pi_O(A_native(r_jam)) = a_tilde x_O b_tilde (42 ops)
        let q3 = oct_cross_pure_inner(&a_tilde, &b_tilde);
        let nq3 = norm7(&q3);
        let mut q3_tilde = [0.0; 16];
        if nq3 > 1e-12 {
            let inv_nq3 = 1.0 / nq3;
            for k in 1..8 {
                q3_tilde[k] = q3[k] * inv_nq3;
            }
        }

        let mut best_norm_sq = -1.0;
        for m in 1..8 {
            let da = a_tilde[m];
            let db = b_tilde[m];
            let dq = q3_tilde[m];
            let nsq = 1.0 - da * da - db * db - dq * dq;
            if nsq > best_norm_sq + 1e-15 {
                best_norm_sq = nsq;
                best_seed_idx = m as i32;
            }
        }
        let m_idx = best_seed_idx as usize;
        let da = a_tilde[m_idx];
        let db = b_tilde[m_idx];
        let dq = q3_tilde[m_idx];
        let mut pm = [0.0; 16];
        for k in 1..8 {
            let em_k = if k == m_idx { 1.0 } else { 0.0 };
            pm[k] = em_k - da * a_tilde[k] - db * b_tilde[k] - dq * q3_tilde[k];
        }
        best_norm = norm7(&pm);
        let inv_best_norm = 1.0 / best_norm;
        let mut best_c = [0.0; 16];
        for k in 1..8 {
            best_c[k] = pm[k] * inv_best_norm;
        }

        let inv_sqrt2 = std::f64::consts::FRAC_1_SQRT_2;
        let ac = oct_cross_pure_inner(&a_tilde, &best_c);
        let acb = oct_cross_pure_inner(&ac, &b_tilde);
        let mut w_moreno = [0.0; 16];
        let mut w_q14 = [0.0; 16];
        let q_scale = 16384.0;
        let inv_q_scale = 1.0 / 16384.0;
        for k in 1..8 {
            let wc = inv_sqrt2 * best_c[k];
            let wd = inv_sqrt2 * acb[k];
            w_moreno[k] = wc;
            w_moreno[k + 8] = wd;
            w_q14[k] = (wc * q_scale).round() * inv_q_scale;
            w_q14[k + 8] = (wd * q_scale).round() * inv_q_scale;
        }

        let mut jam_sq = 0.0;
        let mut sig_sq = 0.0;
        let mut q14_sq = 0.0;
        for k in 0..16 {
            let mut pa = 0.0;
            let mut pb = 0.0;
            let mut jq = 0.0;
            for i in 1..8 {
                let j = k ^ i;
                let s = EPS_T[i][j];
                pa += s * r_jam[i] * w_moreno[j];
                jq += s * r_jam[i] * w_q14[j];
            }
            for i in 9..16 {
                let j = k ^ i;
                let s = EPS_T[i][j];
                pb += s * r_jam[i] * w_moreno[j];
                jq += s * r_jam[i] * w_q14[j];
            }
            let jf = pa + pb;
            let sf = pa - pb;
            jam_sq += jf * jf;
            sig_sq += sf * sf;
            q14_sq += jq * jq;
        }

        let r_jam_energy = sed_norm_sq(&r_jam).max(1e-30);
        let r_sig_energy = sed_norm_sq(&r_sig).max(1e-30);
        fp64_null_db = -10.0 * (jam_sq / r_jam_energy).max(1e-33).log10();
        q14_null_db = -10.0 * (q14_sq / r_jam_energy).max(1e-12).log10();
        sig_gain_db = 10.0 * (sig_sq / r_sig_energy).max(1e-12).log10();
        q3_err = dot7(&q3_tilde, &a_tilde).abs() + dot7(&q3_tilde, &b_tilde).abs();
    }

    // Dominant octonion index a_dom in 1..7 and twist index b_dom in 9..15
    let mut a_dom: usize = 1;
    let mut a_max = -1.0;
    for i in 1..8 {
        let v = u[i].abs();
        if v > a_max {
            a_max = v;
            a_dom = i;
        }
    }
    let mut b_dom: usize = 9;
    let mut b_max = -1.0;
    for i in 9..16 {
        let v = u[i].abs();
        if v > b_max {
            b_max = v;
            b_dom = i;
        }
    }
    let mut b_partner = if (b_dom ^ 8) == a_dom {
        9 + (a_dom % 7)
    } else {
        b_dom
    };
    if (b_partner ^ 8) == a_dom {
        b_partner = 9 + ((a_dom + 1) % 7);
    }
    let s1: i32 = if u[a_dom] * u[b_dom] >= 0.0 { 1 } else { -1 };

    let mut abs_u = [0.0; 16];
    for i in 1..16 {
        abs_u[i] = u[i].abs();
    }
    let mut best_omega: i32 = 1;
    let mut best_score = -1.0;
    for h in 0..15 {
        let idxs = &FANO_H_INDICES[h];
        let score = abs_u[idxs[0]]
            + abs_u[idxs[1]]
            + abs_u[idxs[2]]
            + abs_u[idxs[3]]
            + abs_u[idxs[4]]
            + abs_u[idxs[5]]
            + abs_u[idxs[6]];
        if score > best_score {
            best_score = score;
            best_omega = (h + 1) as i32;
        }
    }

    out_m[0] = assoc_norm_sq;
    out_m[1] = kappa_s;
    out_m[2] = darpa_kappa_s;
    out_m[3] = best_norm;
    out_m[4] = fp64_null_db;
    out_m[5] = q14_null_db;
    out_m[6] = sig_gain_db;
    out_m[7] = q3_err;

    out_i[0] = best_seed_idx;
    out_i[1] = a_dom as i32;
    out_i[2] = b_dom as i32;
    out_i[3] = b_partner as i32;
    out_i[4] = s1;
    out_i[5] = best_omega;
}

// ============================================================================
// Extended N_u Calculus, Co-Axial Multi-Jammer & Hurwitz-Radon [16,8,6]_3 C-ABI
// ============================================================================

pub const TERNARY_16_8_6_PARITY: [[u8; 8]; 8] = [
    [1, 2, 2, 2, 2, 2, 2, 2],
    [2, 2, 2, 1, 2, 1, 1, 2],
    [2, 1, 2, 2, 2, 2, 1, 1],
    [2, 2, 1, 2, 2, 1, 2, 1],
    [2, 1, 1, 1, 2, 2, 2, 2],
    [2, 2, 1, 2, 1, 2, 1, 2],
    [2, 2, 2, 1, 1, 2, 2, 1],
    [2, 1, 2, 2, 1, 1, 2, 2],
];

#[inline(always)]
fn oct_mul_8_f64(a: &[f64; 8], b: &[f64; 8]) -> [f64; 8] {
    let mut out = [0.0; 8];
    for k in 0..8 {
        let mut acc = 0.0;
        for j in 0..8 {
            let i = k ^ j;
            acc += EPS_T[i][j] * a[i] * b[j];
        }
        out[k] = acc;
    }
    out
}

#[inline(always)]
fn oct_assoc_8_f64(a: &[f64; 8], b: &[f64; 8], c: &[f64; 8]) -> [f64; 8] {
    let ab = oct_mul_8_f64(a, b);
    let lhs = oct_mul_8_f64(&ab, c);
    let bc = oct_mul_8_f64(b, c);
    let rhs = oct_mul_8_f64(a, &bc);
    let mut out = [0.0; 8];
    for k in 0..8 {
        out[k] = lhs[k] - rhs[k];
    }
    out
}

#[inline(always)]
pub fn alternativity_defect_inner(u: &[f64; 16], y: &[f64; 16]) -> [f64; 16] {
    let mut a = [0.0; 8];
    let mut b = [0.0; 8];
    let mut c = [0.0; 8];
    let mut d = [0.0; 8];
    a.copy_from_slice(&u[..8]);
    b.copy_from_slice(&u[8..]);
    c.copy_from_slice(&y[..8]);
    d.copy_from_slice(&y[8..]);
    let abd = oct_assoc_8_f64(&a, &b, &d);
    let abc = oct_assoc_8_f64(&a, &b, &c);
    let mut out = [0.0; 16];
    out[..8].copy_from_slice(&abd);
    for k in 0..8 {
        out[8 + k] = -abc[k];
    }
    out
}

#[inline(always)]
fn wedge_lambda_sq_f64(u: &[f64; 16]) -> f64 {
    let mut a_sq = 0.0;
    let mut b_sq = 0.0;
    let mut ab_dot = 0.0;
    for k in 1..8 {
        a_sq += u[k] * u[k];
        b_sq += u[k + 8] * u[k + 8];
        ab_dot += u[k] * u[k + 8];
    }
    (a_sq * b_sq - ab_dot * ab_dot).max(0.0)
}

#[inline(always)]
fn sed_conj_f64(u: &[f64; 16]) -> [f64; 16] {
    let mut out = [0.0; 16];
    out[0] = u[0];
    for i in 1..16 {
        out[i] = -u[i];
    }
    out
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_alternativity_defect_c(
    u_ptr: *const f64,
    y_ptr: *const f64,
    out_ptr: *mut f64,
) {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let y: &[f64; 16] = &*(y_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    *out = alternativity_defect_inner(u, y);
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_mmse_equalize_c(
    u_ptr: *const f64,
    y_ptr: *const f64,
    lambda: f64,
    out_ptr: *mut f64,
) -> i32 {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let y: &[f64; 16] = &*(y_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    let s = sed_norm_sq(u);
    let lam_sq = wedge_lambda_sq_f64(u);
    let tau = s + lambda.max(0.0);
    let den = tau * tau - 4.0 * lam_sq;
    if tau <= 1e-24 || den.abs() <= 1e-20 {
        return 0;
    }
    let uc = sed_conj_f64(u);
    let z0 = sed_mul_inner(&uc, y);
    let z1 = alternativity_defect_inner(u, &z0);
    let z2 = alternativity_defect_inner(u, &z1);
    let c0 = 1.0 / tau;
    let c1 = 1.0 / den;
    let c2 = 1.0 / (tau * den);
    for i in 0..16 {
        out[i] = c0 * z0[i] + c1 * z1[i] + c2 * z2[i];
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_pseudoinverse_zd_c(
    u_ptr: *const f64,
    y_ptr: *const f64,
    out_ptr: *mut f64,
) -> i32 {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let y: &[f64; 16] = &*(y_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    let s = sed_norm_sq(u);
    if s <= 1e-24 {
        return 0;
    }
    let uc = sed_conj_f64(u);
    let z0 = sed_mul_inner(&uc, y);
    let z1 = alternativity_defect_inner(u, &z0);
    let z2 = alternativity_defect_inner(u, &z1);
    let c0 = 1.0 / s;
    let c1 = -1.0 / (4.0 * s * s);
    let c2 = -3.0 / (4.0 * s * s * s);
    for i in 0..16 {
        out[i] = c0 * z0[i] + c1 * z1[i] + c2 * z2[i];
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_project_ker_c(
    u_ptr: *const f64,
    x_ptr: *const f64,
    out_ptr: *mut f64,
) -> i32 {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let x: &[f64; 16] = &*(x_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    let s = sed_norm_sq(u);
    if s <= 1e-24 {
        return 0;
    }
    let n1 = alternativity_defect_inner(u, x);
    let n2 = alternativity_defect_inner(u, &n1);
    let inv = 1.0 / (2.0 * s * s);
    for i in 0..16 {
        out[i] = (n2[i] + s * n1[i]) * inv;
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_coaxial_joint_nuller_c(
    u1_ptr: *const f64,
    u2_ptr: *const f64,
    out_ptr: *mut f64,
) -> i32 {
    let u1: &[f64; 16] = &*(u1_ptr as *const [f64; 16]);
    let u2: &[f64; 16] = &*(u2_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);

    let mut a1 = [0.0; 16];
    let mut b1 = [0.0; 16];
    let mut a2 = [0.0; 16];
    let mut b2 = [0.0; 16];
    a1[1..8].copy_from_slice(&u1[1..8]);
    b1[1..8].copy_from_slice(&u1[9..16]);
    a2[1..8].copy_from_slice(&u2[1..8]);
    b2[1..8].copy_from_slice(&u2[9..16]);

    let c1 = oct_cross_pure_inner(&a1, &b1);
    let c2 = oct_cross_pure_inner(&a2, &b2);
    let n1 = norm7(&c1);
    let n2 = norm7(&c2);
    if n1 <= 1e-12 || n2 <= 1e-12 {
        return 0;
    }
    let cos_align = dot7(&c1, &c2) / (n1 * n2);
    if cos_align < 0.995 {
        return 0;
    }
    let mut n_unit = [0.0; 16];
    for k in 1..8 {
        n_unit[k] = c1[k] / n1;
    }
    let c12 = oct_cross_pure_inner(&a1, &a2);
    let dn = dot7(&c12, &n_unit);
    let mut p0 = [0.0; 8];
    let mut n_oct = [0.0; 8];
    let mut p0_sq = 0.0;
    for k in 1..8 {
        let v = c12[k] - dn * n_unit[k];
        p0[k] = v;
        n_oct[k] = n_unit[k];
        p0_sq += v * v;
    }
    if p0_sq <= 1e-18 {
        return 0;
    }
    let np0 = oct_mul_8_f64(&n_oct, &p0);
    let sc = 1.0 / (2.0 * p0_sq).sqrt();
    for k in 0..8 {
        out[k] = p0[k] * sc;
        out[k + 8] = -np0[k] * sc;
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_hurwitz_radon_spread_c(
    sym9_ptr: *const f64,
    key16_ptr: *const f64,
    out16_ptr: *mut f64,
) {
    let sym = slice::from_raw_parts(sym9_ptr, 9);
    let key: &[f64; 16] = &*(key16_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out16_ptr as *mut [f64; 16]);
    let mut u = [0.0; 16];
    u[..9].copy_from_slice(sym);
    *out = sed_mul_inner(&u, key);
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_hurwitz_radon_despread_c(
    chips16_ptr: *const f64,
    key16_ptr: *const f64,
    out9_ptr: *mut f64,
) -> i32 {
    let chips: &[f64; 16] = &*(chips16_ptr as *const [f64; 16]);
    let key: &[f64; 16] = &*(key16_ptr as *const [f64; 16]);
    let out = slice::from_raw_parts_mut(out9_ptr, 9);
    let key_sq = sed_norm_sq(key);
    if key_sq <= 1e-24 {
        return 0;
    }
    let inv = 1.0 / key_sq;
    for i in 0..9 {
        let mut dot = 0.0;
        for j in 0..16 {
            let k = i ^ j;
            dot += EPS_T[i][j] * key[j] * chips[k];
        }
        out[i] = dot * inv;
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_ternary_16_8_6_encode_c(
    msg8_ptr: *const u8,
    out16_ptr: *mut u8,
) {
    let msg = slice::from_raw_parts(msg8_ptr, 8);
    let out = slice::from_raw_parts_mut(out16_ptr, 16);
    for i in 0..8 {
        out[i] = msg[i] % 3;
    }
    for j in 0..8 {
        let mut acc = 0u16;
        for i in 0..8 {
            acc += (out[i] as u16) * (TERNARY_16_8_6_PARITY[i][j] as u16);
        }
        out[8 + j] = (acc % 3) as u8;
    }
}

#[inline(always)]
fn ternary_col_u8(r: usize, c: usize) -> u8 {
    if c < 8 {
        if r == c { 1 } else { 0 }
    } else {
        TERNARY_16_8_6_PARITY[r][c - 8]
    }
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_ternary_16_8_6_decode_c(
    rx16_ptr: *const u8,
    out8_ptr: *mut u8,
) -> i32 {
    let rx = slice::from_raw_parts(rx16_ptr, 16);
    let out = slice::from_raw_parts_mut(out8_ptr, 8);
    let mut clean = [0u8; 16];
    for i in 0..16 {
        clean[i] = rx[i] % 3;
    }
    let mut syn = [0u8; 8];
    let mut nz = false;
    for r in 0..8 {
        let mut acc = clean[r] as u16;
        for j in 0..8 {
            acc += (TERNARY_16_8_6_PARITY[r][j] as u16) * (clean[8 + j] as u16);
        }
        let rem = (acc % 3) as u8;
        if rem != 0 {
            nz = true;
        }
        syn[r] = rem;
    }
    if !nz {
        out.copy_from_slice(&clean[..8]);
        return 0;
    }
    for c1 in 0..16 {
        for v1 in 1u8..=2 {
            let mut ok = true;
            for r in 0..8 {
                if (ternary_col_u8(r, c1) * v1) % 3 != syn[r] {
                    ok = false;
                    break;
                }
            }
            if ok {
                clean[c1] = (clean[c1] + 3 - v1) % 3;
                out.copy_from_slice(&clean[..8]);
                return 1;
            }
        }
    }
    for c1 in 0..15 {
        for c2 in (c1 + 1)..16 {
            for v1 in 1u8..=2 {
                for v2 in 1u8..=2 {
                    let mut ok = true;
                    for r in 0..8 {
                        if (ternary_col_u8(r, c1) * v1 + ternary_col_u8(r, c2) * v2) % 3 != syn[r] {
                            ok = false;
                            break;
                        }
                    }
                    if ok {
                        clean[c1] = (clean[c1] + 3 - v1) % 3;
                        clean[c2] = (clean[c2] + 3 - v2) % 3;
                        out.copy_from_slice(&clean[..8]);
                        return 2;
                    }
                }
            }
        }
    }
    -1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_pontryagin_max_control_c(
    x_ptr: *const f64,
    p_ptr: *const f64,
    jam_ptr: *const f64,
    gamma_jam: f64,
    rho_effort: f64,
    w_out_ptr: *mut f64,
    h_max_ptr: *mut f64,
) -> i32 {
    let x: &[f64; 16] = &*(x_ptr as *const [f64; 16]);
    let p: &[f64; 16] = &*(p_ptr as *const [f64; 16]);
    let jam: &[f64; 16] = &*(jam_ptr as *const [f64; 16]);
    let w_out: &mut [f64; 16] = &mut *(w_out_ptr as *mut [f64; 16]);

    let g = gamma_jam.max(0.0);
    let r = rho_effort.max(0.0);
    let s = sed_norm_sq(jam);
    let lam_sq = wedge_lambda_sq_f64(jam);
    let tau = r + g * s;
    let den = tau * tau - 4.0 * g * g * lam_sq;
    if tau <= 1e-24 || den <= 1e-24 {
        return 0;
    }

    let xc = sed_conj_f64(x);
    let psi = sed_mul_inner(&xc, p);
    let n1 = alternativity_defect_inner(jam, &psi);
    let n2 = alternativity_defect_inner(jam, &n1);
    let c0 = 1.0 / tau;
    let c1 = g / den;
    let c2 = (g * g) / (tau * den);
    for i in 0..16 {
        w_out[i] = c0 * psi[i] + c1 * n1[i] + c2 * n2[i];
    }

    let xw = sed_mul_inner(x, w_out);
    let jw = sed_mul_inner(jam, w_out);
    let mut pxw = 0.0;
    let mut jw_sq = 0.0;
    let mut w_sq = 0.0;
    for i in 0..16 {
        pxw += p[i] * xw[i];
        jw_sq += jw[i] * jw[i];
        w_sq += w_out[i] * w_out[i];
    }
    if !h_max_ptr.is_null() {
        *h_max_ptr = pxw - 0.5 * g * jw_sq - 0.5 * r * w_sq;
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_pontryagin_zd_control_c(
    x_ptr: *const f64,
    p_ptr: *const f64,
    jam_zd_ptr: *const f64,
    w_out_ptr: *mut f64,
    h_max_ptr: *mut f64,
) -> i32 {
    let x: &[f64; 16] = &*(x_ptr as *const [f64; 16]);
    let p: &[f64; 16] = &*(p_ptr as *const [f64; 16]);
    let jam: &[f64; 16] = &*(jam_zd_ptr as *const [f64; 16]);
    let w_out: &mut [f64; 16] = &mut *(w_out_ptr as *mut [f64; 16]);

    let s = sed_norm_sq(jam);
    if s <= 1e-24 {
        return 0;
    }
    let xc = sed_conj_f64(x);
    let psi = sed_mul_inner(&xc, p);
    let n1 = alternativity_defect_inner(jam, &psi);
    let n2 = alternativity_defect_inner(jam, &n1);
    let inv_2s2 = 1.0 / (2.0 * s * s);
    let mut proj = [0.0; 16];
    let mut p_sq = 0.0;
    for i in 0..16 {
        let v = (n2[i] + s * n1[i]) * inv_2s2;
        proj[i] = v;
        p_sq += v * v;
    }
    if p_sq <= 1e-24 {
        return 0;
    }
    let sc = 1.0 / p_sq.sqrt();
    for i in 0..16 {
        w_out[i] = proj[i] * sc;
    }
    let xw = sed_mul_inner(x, w_out);
    let mut pxw = 0.0;
    for i in 0..16 {
        pxw += p[i] * xw[i];
    }
    if !h_max_ptr.is_null() {
        *h_max_ptr = pxw;
    }
    1
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_aut_s3_phase_c(
    u_ptr: *const f64,
    k_sector: i32,
    reflect: i32,
    out_ptr: *mut f64,
) {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let out: &mut [f64; 16] = &mut *(out_ptr as *mut [f64; 16]);
    let mut base = *u;
    if reflect != 0 {
        for i in 8..16 {
            base[i] = -base[i];
        }
    }
    let km = k_sector.rem_euclid(3);
    let (c, s) = match km {
        0 => (1.0, 0.0),
        1 => (-0.5, 0.86602540378443864676372317075294),
        _ => (-0.5, -0.86602540378443864676372317075294),
    };
    out[0] = base[0];
    out[8] = base[8];
    for idx in 1..8 {
        let ak = base[idx];
        let bk = base[idx + 8];
        out[idx] = c * ak - s * bk;
        out[idx + 8] = s * ak + c * bk;
    }
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_g2_s3_invariants_c(
    u_ptr: *const f64,
    lambda_ptr: *mut f64,
    j3_ptr: *mut f64,
    axis7_ptr: *mut f64,
) {
    let u: &[f64; 16] = &*(u_ptr as *const [f64; 16]);
    let mut a_sq = 0.0;
    let mut b_sq = 0.0;
    let mut ab = 0.0;
    let mut a16 = [0.0; 16];
    let mut b16 = [0.0; 16];
    for k in 1..8 {
        let ak = u[k];
        let bk = u[k + 8];
        a_sq += ak * ak;
        b_sq += bk * bk;
        ab += ak * bk;
        a16[k] = ak;
        b16[k] = bk;
    }
    let cross = oct_cross_pure_inner(&a16, &b16);
    let lam = norm7(&cross);
    if !lambda_ptr.is_null() {
        *lambda_ptr = lam;
    }
    if !axis7_ptr.is_null() {
        let ax = slice::from_raw_parts_mut(axis7_ptr, 7);
        if lam > 1e-15 {
            for k in 0..7 {
                ax[k] = cross[1 + k] / lam;
            }
        } else {
            ax.fill(0.0);
        }
    }
    if !j3_ptr.is_null() {
        let qr = a_sq - b_sq;
        let qi = 2.0 * ab;
        let q_abs = (qr * qr + qi * qi).sqrt();
        if q_abs > 1e-15 {
            let re_q3 = qr * (qr * qr - 3.0 * qi * qi);
            *j3_ptr = (re_q3 / (q_abs * q_abs * q_abs)).clamp(-1.0, 1.0);
        } else {
            *j3_ptr = 0.0;
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_mutually_annihilating_cascade_c(
    u1_ptr: *const f64,
    u2_ptr: *const f64,
    w1_out_ptr: *mut f64,
    w2_out_ptr: *mut f64,
) -> i32 {
    let u1: &[f64; 16] = &*(u1_ptr as *const [f64; 16]);
    let u2: &[f64; 16] = &*(u2_ptr as *const [f64; 16]);
    let w1_out: &mut [f64; 16] = &mut *(w1_out_ptr as *mut [f64; 16]);
    let w2_out: &mut [f64; 16] = &mut *(w2_out_ptr as *mut [f64; 16]);

    let s1 = sed_norm_sq(u1);
    if s1 <= 1e-18 {
        return 0;
    }
    for m in 1..16 {
        let mut em = [0.0; 16];
        em[m] = 1.0;
        let n1 = alternativity_defect_inner(u1, &em);
        let n2 = alternativity_defect_inner(u1, &n1);
        let inv1 = 1.0 / (2.0 * s1 * s1);
        let mut w1 = [0.0; 16];
        let mut w1_sq = 0.0;
        for i in 0..16 {
            let v = (n2[i] + s1 * n1[i]) * inv1;
            w1[i] = v;
            w1_sq += v * v;
        }
        if w1_sq <= 1e-9 {
            continue;
        }
        let sc1 = 1.0 / w1_sq.sqrt();
        for v in w1.iter_mut() {
            *v *= sc1;
        }
        let u1_w1 = sed_mul_inner(u1, &w1);
        if sed_norm_sq(&u1_w1) > 1e-18 {
            continue;
        }

        let u2_prime = sed_mul_inner(u2, &w1);
        let s2 = sed_norm_sq(&u2_prime);
        if s2 <= 1e-12 {
            continue;
        }
        for k in 1..16 {
            let mut ek = [0.0; 16];
            ek[k] = 1.0;
            let k1 = alternativity_defect_inner(&u2_prime, &ek);
            let k2 = alternativity_defect_inner(&u2_prime, &k1);
            let inv2 = 1.0 / (2.0 * s2 * s2);
            let mut z = [0.0; 16];
            for i in 0..16 {
                z[i] = (k2[i] + s2 * k1[i]) * inv2;
            }
            let n1_w1 = alternativity_defect_inner(&w1, &z);
            let n2_w1 = alternativity_defect_inner(&w1, &n1_w1);
            let mut w2 = [0.0; 16];
            let mut w2_sq = 0.0;
            for i in 0..16 {
                let v = (n2_w1[i] + 1.0 * n1_w1[i]) * 0.5;
                w2[i] = v;
                w2_sq += v * v;
            }
            if w2_sq <= 1e-9 {
                continue;
            }
            let sc2 = 1.0 / w2_sq.sqrt();
            for v in w2.iter_mut() {
                *v *= sc2;
            }
            let r_u2 = sed_mul_inner(&u2_prime, &w2);
            let r_w1 = sed_mul_inner(&w1, &w2);
            if sed_norm_sq(&r_u2) <= 1e-16 && sed_norm_sq(&r_w1) <= 1e-16 {
                *w1_out = w1;
                *w2_out = w2;
                return 1;
            }
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn sedenion_pontryagin_bang_bang_84_c(
    x_ptr: *const f64,
    p_ptr: *const f64,
    jam_ptr: *const f64,
    gamma_jam: f64,
    rho_effort: f64,
    meta4_out_ptr: *mut i32,
    w_out_ptr: *mut f64,
    h_max_ptr: *mut f64,
) {
    let x: &[f64; 16] = &*(x_ptr as *const [f64; 16]);
    let p: &[f64; 16] = &*(p_ptr as *const [f64; 16]);
    let jam: &[f64; 16] = &*(jam_ptr as *const [f64; 16]);
    let meta4 = slice::from_raw_parts_mut(meta4_out_ptr, 4);
    let w_out: &mut [f64; 16] = &mut *(w_out_ptr as *mut [f64; 16]);

    let g = gamma_jam.max(0.0);
    let r = rho_effort.max(0.0);
    let inv_sqrt2 = core::f64::consts::FRAC_1_SQRT_2;

    let mut best_h = f64::NEG_INFINITY;
    let mut best_meta = [1i32, 10, 1, 1];
    let mut best_w = [0.0; 16];

    for a in 1usize..=7 {
        for b in 9usize..=15 {
            if (b ^ 8) == a {
                continue;
            }
            for s_in in [1i32, -1] {
                for s_out in [1i32, -1] {
                    let mut w = [0.0; 16];
                    w[a] = (s_out as f64) * inv_sqrt2;
                    w[b] = ((s_out * s_in) as f64) * inv_sqrt2;
                    let xw = sed_mul_inner(x, &w);
                    let jw = sed_mul_inner(jam, &w);
                    let mut pxw = 0.0;
                    let mut jw_sq = 0.0;
                    for i in 0..16 {
                        pxw += p[i] * xw[i];
                        jw_sq += jw[i] * jw[i];
                    }
                    let h = pxw - 0.5 * g * jw_sq - 0.5 * r;
                    if h > best_h {
                        best_h = h;
                        best_meta = [a as i32, b as i32, s_in, s_out];
                        best_w = w;
                    }
                }
            }
        }
    }
    meta4.copy_from_slice(&best_meta);
    *w_out = best_w;
    if !h_max_ptr.is_null() {
        *h_max_ptr = best_h;
    }
}
